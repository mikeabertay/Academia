﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class TextChange : MonoBehaviour
{

    int CampInfo;
    BuildUpController bc = BuildUpController.GetInstance();
    public Text t;

    void Start()
    {
        CampInfo = bc.BuildUpInfo.mycamp;
        if (CampInfo == 1) t.text = "请选择你本局的英雄";
        else t.text = "请等待对方选择英雄";
    }

    void Update()
    {
        if (bc.SecondChoice != 0)
        {
            t.text = "开始游戏！";
        }
        else if (bc.FirstChoice != 0)
        {
            if (CampInfo == 1) t.text = "请等待对方选择英雄";
            else t.text = "请选择你本局的英雄";

        }
    }
}
