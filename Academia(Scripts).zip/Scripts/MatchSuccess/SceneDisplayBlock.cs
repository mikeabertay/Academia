﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SceneDisplayBlock : MonoBehaviour//用于展示动画
{
    BuildUpController bc;
    SceneController sc;
    float startScale=50f;
    void Start()
    {
        bc = BuildUpController.GetInstance();
         sc = SceneController.GetInstance();
        gameObject.GetComponent<Renderer>().material = sc.GetSceneTexture(bc.BuildUpInfo.scene);

    }

    void Update()
    {
        if (bc.SecondChoice != 0)
        {
            startScale += 0.1f;
            transform.localScale = new Vector3(startScale,startScale,1f);
            if (startScale >= 80f)
            {
                sc.SelectBattleField(bc.BuildUpInfo.scene);
            }
        }
    }
}
