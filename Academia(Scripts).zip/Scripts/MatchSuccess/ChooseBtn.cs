﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ChooseBtn : MonoBehaviour
{
    BuildUpController bc;

    void Start()
    {
        bc = BuildUpController.GetInstance();
        Button b = GetComponent<Button>();
        b.onClick.AddListener(onClick);
    }

    void Update()
    {
        
    }

    void onClick()
    {
        if (bc.IsBuildingUp)
        {
            if (bc.BuildUpInfo.mycamp == 1 && bc.FirstChoice == 0)
            {
                bc.SendMyChoose();
            }
            else if (bc.BuildUpInfo.mycamp == 2 && bc.FirstChoice != 0 && bc.SecondChoice == 0)
            {
                bc.SendMyChoose();
            }
            else
            {
                FaultMsg.ThrowFaultMsg("此时您不能选择英雄");
            }
        }
    }
}
