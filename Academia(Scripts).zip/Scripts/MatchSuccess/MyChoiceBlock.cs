﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MyChoiceBlock : MonoBehaviour
{

    public int ID;
    int HeroInfo;
    BuildUpController bc = BuildUpController.GetInstance();


    void Start()
    {
        if (ID == 1) HeroInfo = bc.BuildUpInfo.mydeck1;
        else if (ID == 2) HeroInfo = bc.BuildUpInfo.mydeck2;
        else if (ID == 3) HeroInfo = bc.BuildUpInfo.mydeck3;
        gameObject.GetComponent<Renderer>().material = HeroTexturePainter.PaintHeroTex(HeroInfo);


    }

    void Update()
    {
        if (bc.MyChoice!=0)
        {
            if (HeroInfo != bc.MyChoice)
            {
                transform.Translate(-1f, 0f, 0f);
            }
        }
    }

    public MonoBehaviour cube;

    private void OnMouseUpAsButton()
    {
        bc.ClickedHero = HeroInfo;
        cube.transform.position = new Vector3(transform.position.x, transform.position.y, 99.5f);
    }
}
