﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class OpChoiceBlock : MonoBehaviour
{

    public int ID;
    int HeroInfo;
    BuildUpController bc = BuildUpController.GetInstance();


    void Start()
    {
        if (ID == 1) HeroInfo = bc.BuildUpInfo.opdeck1;
        else if (ID == 2) HeroInfo = bc.BuildUpInfo.opdeck2;
        else if (ID == 3) HeroInfo = bc.BuildUpInfo.opdeck3;
        gameObject.GetComponent<Renderer>().material = HeroTexturePainter.PaintHeroTex(HeroInfo);


    }

    void Update()
    {
        if (bc.OpChoice != 0)
        {
            if (HeroInfo != bc.OpChoice)
            {
                transform.Translate(1f, 0f, 0f);
            }
        }
    }
}
