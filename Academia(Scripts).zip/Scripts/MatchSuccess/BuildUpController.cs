﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BuildUpController 
{
    private static BuildUpController buildUpController = new BuildUpController();


    public static BuildUpController GetInstance()
    {
        return buildUpController;
    }

    public PreDeck[] Decks=new PreDeck[3];

    public void SetDecks(PreDeck deck0, PreDeck deck1, PreDeck deck2)
    {
        Decks[0] = deck0;
        Decks[1] = deck1;
        Decks[2] = deck2;
    }


    public void ClearWhenGaming()
    {
        Decks[0] = null; Decks[1] = null; Decks[2] = null;
        //消息信息的清空
        IsBuildingUp = false;
        BuildUpInfo = null;
        FirstChoice = 0;
        SecondChoice = 0;
        MyChoice = 0;
        OpChoice = 0;
        ClickedHero = 0;
    }

    public bool IsBuildingUp=false;//上一个scene的跳转功能变量

    //----------------------------------------------------------------------------------------------
    public MsgBuildGame BuildUpInfo=null;

    public void RecieveMsgBuildUp(MsgBuildGame msg)
    {
        IsBuildingUp = true;
        //处理消息
        BuildUpInfo = msg;

    }

   // public int BuildUpState;//1为先手选择，2为后手选择，3为选择后等待消息

    public int FirstChoice=0;
    public int SecondChoice=0;

    public int MyChoice=0;
    public int OpChoice=0;

    public void RecieveOneChoose(MsgHeroChoose msg)
    {
        if (msg.camp == BuildUpInfo.mycamp)
        {
            MyChoice = msg.hero;
        }
        else
        {
            OpChoice = msg.hero;
        }
        

        if (msg.camp == 1)
        {
            FirstChoice = msg.hero;
            
            //消息 1处理逻辑
        }
        else if (msg.camp == 2)
        {
            SecondChoice = msg.hero;
            //消息2处理逻辑
            
        }

    }

    public int ClickedHero = 0;

    public void SendMyChoose()
    {
        if (ClickedHero != 0)
        {
            SocketHelper sh = SocketHelper.GetInstance();
            MsgHeroChoose msg = new MsgHeroChoose();
            msg.mission = "choosehero";
            msg.camp = BuildUpInfo.mycamp;
            msg.hero = ClickedHero;
            string str = JsonUtility.ToJson(msg);
            sh.SendMessage(str);
        }
        else
        {
            FaultMsg.ThrowFaultMsg("请选择英雄");
        }
    }
}
