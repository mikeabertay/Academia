﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FaultMsg : MonoBehaviour
{
    string faultMessage;

    void Start()
    {
        
    }


    void Update()
    {
        
    }

    //显示错误输入的原因，具体实现以后再说
    public static void ThrowFaultMsg(string msg)
    {
        Debug.Log(msg);
        GlobalText.GetInstance().DisplayFaultMsg(msg);
    }
}
