﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class GameController //游戏对局控制器
{
    private static GameController gameController = new GameController();


    public static GameController GetInstance()
    {
        return gameController;
    }

    public bool IsInBattle = false;//是否正在对战中
    public bool IsSkippingAnime = false;//是否跳过动画，仅在掉线重连时为true


    public void ClearThisBattle()//对局结束后清理数据
    {
        IsInBattle = false;
        IsSkippingAnime = false;
        heroController1 = null;
        heroController2=null;
        MyCamp = 0;
        WhoseTurn = 0;
        TurnNum = 1;
        MyHand = 0;
        OpHand = 0;
        MyDeck.Clear();
        OpDeck = 0;
        Graveyard.Clear();
        BattleField.ClearAllBlocks();
        //BattleField = null;
        //OccupantList.Clear();
        RandomNumListPoint = 0;
        ClearHistory();
        ClearInput();
    }

    //-------------------------------------构建游戏--------------------------------------

    public HeroController heroController1;
    public HeroController heroController2;

    public bool ReadyToBuild = false;

    public void BuildUpGameInScene()
    {
        ///////////////////////////////////试玩版////////////////////////////////////
        //heroController1.SetData(MyCamp, MyCamp);//试玩版数据,初始化英雄
        //heroController2.SetData(3 - MyCamp, 3 - MyCamp);
        heroController1 = new HeroController();
        heroController2 = new HeroController();
        heroController1.SetData(1, 1);
        heroController2.SetData(2, 2);

        BattleField.SetHeroesIntoScene(heroController1);
        BattleField.SetHeroesIntoScene(heroController2);//英雄入场
        Debug.Log(BattleField);
        //初始化卡组
        BattleField.StartGameBuildUpDeck(new int[30]);
        OpDeck = 30;
        //初始化手牌
        BattleField.SetHandHorizontalNum(MyCamp);
        BattleField.StartGameDraw();
        if (WhoseTurn == MyCamp) FaultMsg.ThrowFaultMsg("你的回合");
        else FaultMsg.ThrowFaultMsg("对方回合");

        /////////////////////////////////试玩版结束//////////////////////////////////
    }


    //-------------------------------------回合控制--------------------------------------

    public int MyCamp;//阵营，1先手，2后手，0中立

    public int WhoseTurn = 0;

    public int TurnNum = 1;


    //--------------------------------------手牌处理--------------------------------------
    //我方手牌
    public int MyHand = 0;

    //对方手牌
    public int OpHand = 0;

    public void DrawCard(int camp)
    {
        if (MyCamp != camp)
        {
            if (OpHand < BattleField.HandMax && OpDeck > 0)
            {
                OpHand++;
                OpDeck--;
                UseRandomNum();
            }
        }
        else
        {
            if (MyHand < BattleField.HandMax && MyDeck.Count > 0)
            {
                Block b = BattleField.FindHandBlock(MyHand+1);
                int random = UseRandomNumInAnotherRange(MyDeck.Count);
                UnusedCard uc = MyDeck[random] as UnusedCard;
                MyDeck.RemoveAt(random);
                b.HandEnterBlock(uc);
                MyHand++;
            }
        }

        foreach (object obj in OccupantList)
        {
            TriggerAble ta = obj as TriggerAble;
            if (ta != null) ta.DrawCard(camp);
        }
    }

    public void CreateCard(UnusedCard uc, int camp)
    {
        if (MyCamp != camp)
        { if (OpHand < BattleField.HandMax) OpHand++; }
        else
        {
            if (MyHand < BattleField.HandMax)
            {
                MyHand++;
                Block b = BattleField.FindHandBlock(MyHand + 1);
                b.HandEnterBlock(uc);
            }
        }
    }
    /*函数无意义，本质上消息处理不了复杂的弃牌，只能简单弃牌
    public void Discard(int dis, int camp)
    {
        UnusedCard uc = null;
        if (MyCamp != camp)
        { if (OpHand > 0) OpHand--; }
        else
        {
            if (MyHand > 0)
            {
                MyHand--;
                uc = BattleField.FindHandBlock(dis).Card;
                BattleField.DispatchCards(dis);
            }
        }
        if (uc != null)
        {
            foreach (object obj in OccupantList)
            {
                TriggerAble ta = obj as TriggerAble;
                if (ta != null) ta.DiscarCard(camp, uc);
            }
        }
    }*/

    //--------------------------------------卡组处理--------------------------------------
    //我方卡组
    public ArrayList MyDeck = new ArrayList();

    //对方卡组
    public int OpDeck = 0;

    public void AddToDeck(UnusedCard c, int camp)
    {
        if (MyCamp != camp) OpDeck++;
        else MyDeck.Add(c);
    }

    public void RemoveFromDeckByObj(UnusedCard c, int camp)
    {
        if (MyCamp != camp) OpDeck--;
        else MyDeck.Remove(c);
    }

    public void RemoveFromDeckByIndex(int index, int camp)
    {
        if (MyCamp != camp) OpDeck--;
        else MyDeck.RemoveAt(index);
    }

    public void RandomRemove(int camp)
    {
        if (MyCamp != camp) OpDeck--;
        else
        {
            int random = UseRandomNumInAnotherRange(MyDeck.Count);
            MyDeck.RemoveAt(random);
        }
    }
    //--------------------------------------墓地处理--------------------------------------
    //墓地
    public ArrayList Graveyard = new ArrayList();
    public void AddToGraveyard(TriggerAble t)
    {
        Graveyard.Add(t);
    }



    //--------------------------------------场地处理--------------------------------------
    //场面
    public Field BattleField;
    //场面队列
    public ArrayList OccupantList = new ArrayList();


    //-------------------------------------随机表---------------------------------------
    //随机数列表
    int[] RandomNumList = new int[100];
    //获取随机数的方法
    public int UseRandomNum()
    {
        int r = RandomNumList[RandomNumListPoint];
        if (RandomNumListPoint == 99) RandomNumListPoint = 0;
        else RandomNumListPoint++;
        return r;
    }

    public int UseRandomNumInAnotherRange(int range)
    {
        int random = UseRandomNum();

        int d = random * range / 100;

        return d;
    }
    int RandomNumListPoint = 0;//指针指向接下来要用的随机数

    public void SetRandomList(int[] a)//设置随机数表
    {
        if (a.Length == 100)
            for (int i = 0; i < 100; i++)
            {
                RandomNumList[i] = a[i];
            }
    }

    //-------------------------------------历史记录---------------------------------------
    //历史记录序号
    int HistoryNum = 0;
    //历史记录
    ArrayList HistoryList = new ArrayList();
    //添加历史记录
    public void AddHistory(MsgInBattle msg)
    {
        HistoryNum++;
        HistoryList.Add(msg);
    }
    //清除历史记录
    public void ClearHistory()
    {
        HistoryNum = 0;
        HistoryList.Clear();
    }

    public int GetHistory()
    {
        return HistoryNum;
    }
    //--------------------------------------画面反馈-----------------------------------------
    public DisplayCard displayCard = null;

    //---------------------------------------输入-----------------------------------------
    public Block effecter = null;
    public Block target = null;
    public int controlnum = -1;
    public int additionalnum = -1;
    public int quicknum = -1;
    public int quickstate = -1;

    public Block blockDisplayingPanel = null;//正在打开panel的block
    public GameObject PanelOnDisplaying = null;

    public void ClearInput()
    {
        effecter = null;
        target = null;
        controlnum = -1;
        additionalnum = -1;
        quicknum = -1;
        quickstate = -1;
    }

    public void CheckInput()
    {
        effecter.CheckInput();
    }

    //-------------------------------------消息处理---------------------------------------

    //发消息

    public void SendBattleMsg()
    {
        MsgInBattle msg = new MsgInBattle();
        msg.mission = "battle";
        msg.msgNum = HistoryNum;
        msg.effecterHorizontal = effecter.HorizontalSequence;
        msg.effecterVertical = effecter.VerticalSequence;
        msg.targetHorizontal = target.HorizontalSequence;
        msg.targetVertical = target.VerticalSequence;
        msg.controlNum = controlnum;
        msg.additionalNum = additionalnum;
        msg.quicknum = quicknum;
        msg.quickstate = quickstate;
        SocketHelper sh = SocketHelper.GetInstance();
        string str = JsonUtility.ToJson(msg);
        //Debug.Log(str);
        sh.SendMessage(str);

        ClearInput();
    }
    //处理消息
    public Block FindTarget(MsgInBattle msg)
    {
        return null;
    }
    //-------------------------------------游戏结束-----------------------------------------
    public bool GameOverDicision()//返回true游戏结束，返回false游戏继续！！！要在每次消息处理后调用一下，否则检测不到
    {
        if (MyLose && OpLose)
        {
            Deuce();
            return true;
        }
        else if (MyLose)
        {
            LoseTheGame();
            return true;
        }
        else if (OpLose)
        {
            WinTheGame();
            return true;
        }
        else
        {
            return false;
        }
    }

    public bool MyLose = false;
    public bool OpLose = false;

    public void WinTheGame()
    {
        SendEndGameMsg("win");
        FaultMsg.ThrowFaultMsg("你赢了！");
    }
    public void LoseTheGame()
    {
        SendEndGameMsg("lose");
        FaultMsg.ThrowFaultMsg("你输了……");

    }
    public void Deuce()
    {
        SendEndGameMsg("deuce");
        FaultMsg.ThrowFaultMsg("平局");
    }

    public void SendEndGameMsg(string result)
    {
        MsgResult msg = new MsgResult();
        msg.mission = "finish";
        msg.result = result;
        SocketHelper sh = SocketHelper.GetInstance();
        string str = JsonUtility.ToJson(msg);
        Debug.Log(str);
        sh.SendMessage(str);

        MyLose = false;
        OpLose = false;

        ClearThisBattle();
        SceneManager.LoadScene("TestScene"); 
    }
}
