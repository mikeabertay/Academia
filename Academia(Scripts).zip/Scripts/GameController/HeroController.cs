﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class HeroController 
{
  /*  private static Hashtable HeroInitList = new Hashtable();
    
    public HeroController()
    {
        if (HeroInitList.Count == 0)
        {
            HeroInitList.Add(0, null);
            HeroInitList.Add(1, typeof(CreatrueTest) );
        }
    }*/
    public ArrayList heroList=new ArrayList();


    public void BuildUpHero(int heroNum)
    {
        switch (heroNum)
        {
            case 1:
                heroList.Add(new Hero1(this));
                break;
            case 2:
                heroList.Add(new Hero2(this));
                //heroList.Add(new Hero1(this));
                break;

            default:

                break;
        }

    }

    public int thisCamp=0;

    public void AddHero(Hero h)
    {
        heroList.Add(h);

    }

    public void RemoveHero(Hero h)
    {
        heroList.Remove(h);
        if (heroList.Count == 0) EndGameBecauseDeath();
    }

    public void Clear()
    {
        thisCamp = 0;
        heroList.Clear();
    }

    public void SetData(int camp,int heroNum)
    {
        thisCamp = camp;
        BuildUpHero(heroNum);
    }

    public void EndGameBecauseDeath()//该控制器下的英雄输了
    {
        GameController gc = GameController.GetInstance();
        if (gc.MyCamp == thisCamp) gc.MyLose = true;
        if (gc.MyCamp != thisCamp) gc.OpLose = true;
    }
}
