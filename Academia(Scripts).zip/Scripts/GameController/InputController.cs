﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class InputController : MonoBehaviour
{
    void Start()
    {

    }

    void Update()
    {
        //if (effectObj != null)
        //{
        //    if (targetblock != null)
        //    {

        //    }
        //}

        //else if (effectCard != null)
        //{
        //    if (targetblock != null)
        //    {

        //    }
        //}

    }

    public Block effecter;
    public Block target;
    public int controlnum;
    public int additionalnum;
}
