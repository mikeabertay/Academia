﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DisplayCard : MonoBehaviour
{
    void Start()
    {
        GameController gc = GameController.GetInstance();
        gc.displayCard = this;
    }

    void Update()
    {
        if(IsDisplaying)i++;
        if (i > 150) Hide();
    }

    public void Hide()
    {
        transform.position = new Vector3(0f, 10f, 110f);

        IsDisplaying = false;

        i = 0;
    }

    public void Display(string path)
    {
        gameObject.GetComponent<Renderer>().material = Resources.Load<Material>(path);

        transform.position = new Vector3(0f, 10f, 80f);

        IsDisplaying = true;

    }
    bool IsDisplaying = false;
    int i = 0;

    private void OnMouseDown()
    {
        GameController gc = GameController.GetInstance();
        //gc.ClearInput();
    }

    private void OnMouseUp()
    {
        GameController gc = GameController.GetInstance();
        gc.ClearInput();
    }
}
