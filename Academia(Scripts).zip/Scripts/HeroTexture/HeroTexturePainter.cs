﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class HeroTexturePainter : MonoBehaviour//写的太苟了，以后再改吧
{
    public static int HeroTotal = 6;

    public static Material Default = null;
    public Material DefaultHeroTex;
    public Material Hero1;
    public Material Hero2;
    public Material Hero3;
    public Material Hero4;
    public Material Hero5;
    public Material Hero6;
    public static Material[] Heroes=new Material[HeroTotal+1];

    public static Material PaintHeroTex(int id)
    {
        if (id > HeroTotal || id <= 0)
        {
            return Default;
        }
        else {
            return Heroes[id];
        }
    }

    void Start()
    {
        Default = DefaultHeroTex;
        Heroes[1] = Hero1;
        Heroes[2] = Hero2;
        Heroes[3] = Hero3;
        Heroes[4] = Hero4;
        Heroes[5] = Hero5;
        Heroes[6] = Hero6;
    }
}
