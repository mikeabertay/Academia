﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AnimeFactory : MonoBehaviour
{
    static AnimeFactory animeFactory;

    public static AnimeFactory GetInstance()
    {
        return animeFactory;
    }

    void Start()
    {
        animeFactory = this;
    }

    public void DisplayDamageText(int a, Transform t)
    {
        Object go = Resources.Load("Anime/DamageText/damagetext", typeof(GameObject));
        GameObject obj;

        if (go != null)
        {
            obj = Instantiate(go) as GameObject;
            obj.GetComponent<DamageText>().SetNum(a);
            obj.transform.position = new Vector3(t.position.x, t.position.y + 6, 93);
        }

    }

    public void DisplaySpotLight(Transform t)
    {
        Object go = Resources.Load("Anime/SpotLight/spotlight", typeof(GameObject));
        GameObject obj;

        if (go != null)
        {
            obj = Instantiate(go) as GameObject;
            obj.transform.position = new Vector3(t.position.x, t.position.y , -15);
        }

    }
}
