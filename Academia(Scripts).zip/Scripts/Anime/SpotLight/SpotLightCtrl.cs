﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SpotLightCtrl : MonoBehaviour
{
    void Start()
    {
        
    }

    void Update()
    {
        i++;
        if (i > 200) Destroy(gameObject);
    }

    int i = 0;
}
