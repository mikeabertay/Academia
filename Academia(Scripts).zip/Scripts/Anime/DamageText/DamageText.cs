﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DamageText : MonoBehaviour
{
    void Start()
    {

    }

    void Update()
    {
        i++;
        transform.Translate(new Vector3(0, 0.02f, 0));
        if (i == 100) Destroy(gameObject);
    }
    int i = 0;
    public TextMesh damageText;

    public void SetNum(int a)
    {
        damageText.text = "-" + a.ToString();
    }


}
