﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TagPool;

public class Hero1 : Hero
{
    GameController gc = GameController.GetInstance();

    public override void CheckInput()
    {
        if (gc.controlnum != -1)
        {
            if (gc.controlnum < Actions.Count)
            {
                if (gc.MyCamp == gc.WhoseTurn)
                {
                    ActionDel ad = Actions[gc.controlnum] as ActionDel;
                    ad.ActionInputCheck();
                }
                else
                {
                    FaultMsg.ThrowFaultMsg("回合外不能进行操作");
                }
            }
            else
            {
                FaultMsg.ThrowFaultMsg("操作数异常");
            }
        }
        else
        {
            FaultMsg.ThrowFaultMsg("请选择行动");
        }
    }

    public override void HandleMsg(MsgInBattle msg)
    {
        if (msg.controlNum < Actions.Count && msg.controlNum >= 0)
        {
            ActionDel ad = Actions[msg.controlNum] as ActionDel;
            ad.ActionHandleMsg(msg);
        }
    }

    public override UnusedCard GetElement(int num)
    {
        switch (num)
        {
            case 0:
                return new UnusedCard(MaterialPath, "");
            case 1:
                return Sword;

            case 2:
                return Shield;

            case 3:
                return Corslet;

            default:
                return null;
        }
    }

    public override void SetElement(UnusedCard uc, MsgInBattle msg)
    {

        switch (msg.additionalNum)
        {
            case 1:
                Sword = uc;
                break;
            case 2:
                Shield = uc;
                break;
            case 3:
                Corslet = uc;
                break;
            default:
                break;
        }
    }

    public UnusedCard Sword = null;
    public UnusedCard Shield = null;
    public UnusedCard Corslet = null;







    public ActionDel CommonAttack;
    public ActionDel CommonMove;

    public void ICCommonAttack()
    {
        if (gc.target.thisType == Block.TargetType.Occupant)
        {
            if (ActionPoint > 0)
            {
                if (!gc.target.GetIsEmpty())
                {
                    if (gc.target.Owner.GetCanAttacked())
                    {
                        gc.SendBattleMsg();//发送消息
                        Debug.Log("没问题的");
                    }
                    else
                    {
                        FaultMsg.ThrowFaultMsg("该目标不可攻击");
                    }
                }
                else
                {
                    FaultMsg.ThrowFaultMsg("该区域无目标可攻击");
                }
            }
            else
            {
                FaultMsg.ThrowFaultMsg("行动力不足");
            }
        }
        else
        {
            FaultMsg.ThrowFaultMsg("请选择正确的攻击目标");
        }
    }

    public void HMCommonAttack(MsgInBattle msg)
    {
        if (msg.targetHorizontal >= 0)
        {
            Block b = gc.BattleField.FindOccupantBlock(msg.targetHorizontal, msg.targetVertical);
            TriggerAble t = b.Owner;
            if (t != null)
            {
                ActionPoint--;
                t.GetAttackedBy(this);
                if (!BreakOffState) t.GetDamage(AttackPoint, 0);
            }
        }
    }

    public void ICCommonMove()
    {
        if (gc.target.thisType == Block.TargetType.Occupant)
        {
            if (ActionPoint > 0)
            {
                if (gc.target.GetIsEmpty())
                {
                    if (gc.target.HorizontalSequence > 0)
                    {
                        gc.SendBattleMsg();//发送消息
                        Debug.Log("没问题的");
                    }
                }
                else
                {
                    FaultMsg.ThrowFaultMsg("该区域已被占领");
                }
            }
            else
            {
                FaultMsg.ThrowFaultMsg("行动力不足");
            }
        }
        else
        {
            FaultMsg.ThrowFaultMsg("请选择正确的移动位置");
        }
    }

    public void HMCommonMove(MsgInBattle msg)
    {
        ActionPoint--;
        Block b = gc.BattleField.FindOccupantBlock(msg.targetHorizontal, msg.targetVertical);
        Block ter = Territory;
        b.OccupantEnterBlock(this);
        ter.ClearBlock();

        //Territory的trap入场处理
        //移动效果不同的处理
    }

    public new void Init()
    {
        CommonAttack = new ActionDel("ActionBlock/Material/CommenAttack", ICCommonAttack, HMCommonAttack);
        CommonMove = new ActionDel("ActionBlock/Material/CommenMove", ICCommonMove, HMCommonMove);

        PanelPath = "Panel/Hero/Hero1";

        MaterialPath = "Picture/Hero/Hero1";
    }

    public Hero1(HeroController hc)
    {
        Camp = hc.thisCamp;

        ActionPoint = 2;

        HealthPoint = 30;
        AttackPoint = 3;

        heroController = hc;
        Init();
        AddAction(CommonAttack);
        AddAction(CommonMove);
        //外部设置Camp，由HeroController进行

        GetDamage = FuncGetDamage;
        StartTurn = FuncStartTurn;
        Disarm = FuncDisarm;
    }

    public new void FuncGetDamage(int pysical, int magical)
    {
        HealthPoint -= pysical + magical;
        if (pysical > 0) AnimeFactory.GetInstance().DisplayDamageText(pysical, Territory.transform);
        if (magical > 0) AnimeFactory.GetInstance().DisplayDamageText(magical, Territory.transform);

        if (Territory.infoBlock != null) SetInfo();
        if (HealthPoint <= 0)
        {
            BreakOffState = true;
            heroController.RemoveHero(this);
            gc.OccupantList.Remove(this);
            Territory.ClearBlock();
        }
    }


    public new void FuncStartTurn()
    {
        ActionPoint = 2;
        if (gc.WhoseTurn == gc.MyCamp) gc.DrawCard(Camp);
    }

    public new void FuncDisarm()
    {
        Sword = null;
    }
}
