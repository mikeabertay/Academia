﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ActionBlock : MonoBehaviour
{
    void Start()
    {
        
    }
    
    void Update()
    {
        
    }

    int controlNum;
    Block parent;

    public void SetData(Block b,int cn)
    {
        controlNum = cn;
        parent = b;
    }

    public void SetPosition(int i ,int totalnum,Vector3 pos)//调整到好看的位置
    {
        int px = (totalnum - 1) * -8 +i  * 16;
        transform.position = new Vector3(pos.x + px, pos.y + 20, 98);
    }

    private void OnMouseExit()
    {
        GameController gc = GameController.GetInstance();
        gc.controlnum = controlNum;
        parent.DestoyAllActionBlocks();
    }

    private void OnMouseUp()
    {
        GameController gc = GameController.GetInstance();
        FaultMsg.ThrowFaultMsg("必须为行动选择一个目标");
        gc.ClearInput();
    }
}
