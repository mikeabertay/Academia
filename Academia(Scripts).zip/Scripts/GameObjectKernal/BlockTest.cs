﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TagPool;

public class BlockTest : Block
{
   // private string spherePath = "Sphere";

    void Start()
    {
        //  Object spherePreb = Resources.Load(spherePath, typeof(GameObject));

        //  GameObject sphere = Instantiate(spherePreb) as GameObject;

        OccupantEnterBlock(new CreatrueTest());
        //OccupantEnterBlock(new CardA());
        //Card = new CardTest();

    }

    void Update()
    {

    }

}
