﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ActionDel 
{
    public delegate void InputCheckDelegate();
    public delegate void HandleMsgDelegate(MsgInBattle msg);

    public InputCheckDelegate ActionInputCheck;
    public HandleMsgDelegate ActionHandleMsg;

    public Object fab;//行动块fab
    public string fabPath= "ActionBlock/ActionBlock";

    public string matPath;

    public ActionDel()
    {
        //构造一个空的Action
    }

    public ActionDel(string path,InputCheckDelegate inputdel,HandleMsgDelegate msgdel)
    {
        matPath = path;
        ActionInputCheck = inputdel;
        ActionHandleMsg = msgdel;

        fab = Resources.Load(fabPath, typeof(GameObject));
    }

}
