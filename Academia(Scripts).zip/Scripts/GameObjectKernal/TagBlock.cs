﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CardTagBlock
{
    public bool IsPackage=false;
    public bool IsCurrency = false;
    public bool IsPlant = false;
    public bool IsAnimal = false;
    public bool IsAnimalEgg = false;
    public bool IsPlantSeed = false;
    public bool IsPlantBud = false;
    public bool IsPlantGrass = false;
    public bool IsPlantTree = false;
    public bool IsPlantFlower = false;
    public bool IsMineral = false;
    public bool IsMetal = false;
    public bool IsEnergy = false;
    public bool IsContract = false;
    public bool IsMagicScroll = false;
    public bool IsEquipmentWeapon = false;
    public bool IsEquipmentCorslet = false;
    public bool IsEquipmentAccessory = false;
    public bool IsItem = false;
    public bool IsItemFood = false;
    public bool IsItemMedicament = false;
    public bool IsPoison = false;


}
