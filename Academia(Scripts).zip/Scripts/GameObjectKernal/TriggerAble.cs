﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public abstract class TriggerAble
{
    public int Camp;//阵营，0中立，其余与控制器进行匹配，相同则为己方的

    public Block Territory;//反绑

    //public Material Texture;
    public string MaterialPath;//卡图的路径，子类修改

    public abstract UnusedCard GetElement(int num);
    //帮助Panel Element找到Material，子类实现，0为本体插画

    public abstract void SetElement(UnusedCard uc, MsgInBattle msg);
    //接收消息后被动调用该函数，没有元素的occupant可以不做任何事，目前类型尚未确定！！！

    public abstract void CheckInput();
    //判断逻辑，发送消息逻辑，子类实现
    //不合理的状况FaultMsg，合理则发消息

    public abstract void HandleMsg(MsgInBattle msg);
    //接到消息后的执行逻辑，子类实现
    //不合理的状况FaultMsg，合理则调用委托

    //public GameObject Panel;//放置跳出的面板,初始化需要载入一下

    public string PanelPath;//用于初始化的面板路径，在进入block的时候加载，子类修改


    public ArrayList Actions = new ArrayList();//行动数组

    public delegate void DelForAction(ActionDel action);
    public DelForAction AddAction;
    public void FuncAddAction(ActionDel action)
    {
        Actions.Add(action);
    }

    public DelForAction RemoveAction;
    public void FuncRemoveAction(ActionDel action)
    {
        Actions.Remove(action);
    }

    public ArrayList GetActions()
    {
        return Actions;
    }

    public ArrayList Buffs = new ArrayList();

    public delegate void BuffDel(Buff buff);
    public BuffDel AddBuff;
    public void FuncAddBuff(Buff buff)
    {
        Buffs.Add(buff);
        buff.GetBuff();
    }

    public BuffDel RemoveBuff;
    public void FuncRemoveBuff(Buff buff)
    {
        Buffs.Remove(buff);
        buff.EndBuff();
    }

    public int ActionPoint = 0;//数据块，使用时进行设置

    public int HealthPoint = 0;
    public int AttackPoint = 0;

    public int Armor = 0;
    public int MagicalResistance = 0;

    public void Init()//模型初始化，在构建卡组时或new时调用，需要子类实现
    {

    }

    public TriggerAble()
    {
        AddAction = FuncAddAction;
        RemoveAction = FuncRemoveAction;
        AddBuff = FuncAddBuff;
        RemoveBuff = FuncRemoveBuff;

        GetDamage = FuncGetDamage;
        StartTurn = FuncStartTurn;
        GetAttackedBy = FuncGetAttacked;
        Disarm = FuncDisarm;
        GetElementalDamage = FuncGetElementalDamage;
        EndTurn = FuncEndTurn;
    }

    public bool BreakOffState = false;//用于中断多段效果的函数，一旦死亡，中断之后的所有操作

    public void StartGame() { }//游戏开始时的效果
    //单个回合开始时
    public delegate void StartTurnDel();
    public StartTurnDel StartTurn;
    public void FuncStartTurn()
    {

    }

    //单个回合结束时
    public delegate void EndTurnDel();
    public EndTurnDel EndTurn;
    public void FuncEndTurn()
    {

    }

    //该游戏对象受到伤害时
    public delegate void GetDamageDel(int pysical, int magical);
    public GetDamageDel GetDamage;
    public void FuncGetDamage(int pysical, int magical)
    {

    }
    //第二种受伤函数
    public delegate void GetElementalDamageDel(int[] damages);
    public GetElementalDamageDel GetElementalDamage;
    public void FuncGetElementalDamage(int[]damages)
    {

    }
    //缴械时
    public delegate void DisarmDel();
    public DisarmDel Disarm;
    public void FuncDisarm()
    {

    }

    //被攻击时的效果
    public delegate void GetAttackedDel(TriggerAble t);
    public GetAttackedDel GetAttackedBy;
    public void FuncGetAttacked(TriggerAble t)
    {

    }

    public void OthersGetDamage() { }//其他游戏对象受到伤害时

    public void GetIntensification() { }//该游戏对象任何数值强化时

    public void OthersGetIntensification() { }//其他游戏对象任何数值强化时

    public void IntoBattleField() { }//入场时

    public void OthersIntoBattleField() { }//其他游戏对象入场时

    public void Dead() { }//死亡时

    public void OthersDead() { }//其他游戏对象死亡时

    public void DrawCard(int camp) { }//摸牌的时候

    public void DiscarCard(int camp, UnusedCard uc) { }//弃牌的时候

    bool CanAttacked = true;
    public bool GetCanAttacked()
    {
        return CanAttacked;
    }

    public void SetInfo()
    {
        Territory.SetInfo(AttackPoint, HealthPoint);
    }
}
