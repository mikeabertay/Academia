﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TagPool;

public class CardTest : UnusedCard,IMagicScollTag
{
    public void MagicEffect()
    {
        Debug.Log("magic");
    }

    public new void FunctionHandle(MsgInBattle msg)//HandleMsg
    {

    }

    public new void FunctionCheck()//CheckInput
    {

    }

    public CardTest()
    {
        CardNum = 0;
        CheckInput = FunctionCheck;
        HandleMsg = FunctionHandle;

        MaterialPath = "r";

        WholePicturePath = "r";
    }
}
