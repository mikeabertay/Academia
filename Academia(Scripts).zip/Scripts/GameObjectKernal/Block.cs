﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Block : MonoBehaviour
{
    void Start()
    {
        GameController gc = GameController.GetInstance();
        DefaultMaterial = gc.BattleField.BlockDefaultMaterial;
        gameObject.GetComponent<Renderer>().material = DefaultMaterial;

        if (thisType == TargetType.Hand) HideBlock();
    }

    void Update()
    {

    }

    public int HorizontalSequence;//第几行
    public int VerticalSequence;//第几列

    //string Terrian;//地形，暂时无设计，保留数据段，但如果用数据结构估计还得改

    public enum TargetType
    {
        Hand,
        Occupant
    }
    public TargetType thisType;

    public TriggerAble Owner;
    public UnusedCard Card;

    public void CheckInput()
    {
        if (thisType == TargetType.Hand)
        {
            Card.CheckInput();
        }
        else if (thisType == TargetType.Occupant)
        {
            Owner.CheckInput();
        }
    }

    GameController gameController = GameController.GetInstance();

    void OnMouseDown()
    {
        targetBlock = this;
        if (thisType == TargetType.Hand)
        {
            if (Card != null)
            {
                gameController.effecter = this;
                //输入反馈需要实现
                gameController.displayCard.Display(Card.WholePicturePath);//点击查看卡牌效果
            }
        }
        else if (thisType == TargetType.Occupant)
        {
            if (Owner != null)
            {
                if (gameController.MyCamp == Owner.Camp)//如果是可操控的单位
                //if(true)
                {
                    gameController.effecter = this;
                    //输入反馈需要实现
                    ArrayList al = Owner.GetActions();//显示行动块
                    int num = al.Count;
                    foreach (object a in al)
                    {
                        ActionDel ad = a as ActionDel;
                        GameObject obj = Instantiate(ad.fab) as GameObject;
                        ActionBlocks.Add(obj);
                        obj.GetComponent<ActionBlock>().SetData(this, i);
                        obj.GetComponent<Renderer>().material = Resources.Load<Material>(ad.matPath);
                        obj.GetComponent<ActionBlock>().SetPosition(i, num , transform.position);
                        i++;
                    }
                    i = 0;
                }
            }
        }
    }

    ArrayList ActionBlocks = new ArrayList();//保存行动块
    public void DestoyAllActionBlocks()//清理行动块
    {
        foreach (object a in ActionBlocks)
        {
            GameObject obj = a as GameObject;
            Destroy(obj);
        }
        ActionBlocks.Clear();
    }

    int i = 0;

    private void OnMouseEnter()
    {
        targetBlock = this;
    }
    private void OnMouseExit()
    {
        targetBlock = null;
        gameController.displayCard.Hide();//点击查看卡牌效果
    }

    static Block targetBlock;
    void OnMouseUp()
    {
        gameController.displayCard.Hide();//点击查看卡牌效果

        if (Card == null && Owner == null) return;
        if (targetBlock != null)
        {
            if (targetBlock.thisType == TargetType.Hand)
            {
                if (!targetBlock.NotSame(gameController.effecter))
                {
                    gameController.ClearInput();
                }
                else
                {
                    if (targetBlock.Card != null)
                    {
                        gameController.target = targetBlock;
                        gameController.CheckInput();
                    }
                }

            }
            else if (targetBlock.thisType == TargetType.Occupant)
            {
                if (!targetBlock.NotSame(gameController.effecter))
                {
                    gameController.ClearInput();
                    targetBlock.DisplayPanel();
                }
                else
                {
                    Debug.Log("ready");
                    //if (targetBlock.Owner != null)//现在支持目标为空，具体判断都放在子类

                    gameController.target = targetBlock;
                    gameController.CheckInput();

                }
            }
        }
        else if (PanelBlock.targetPanelBlock != null)
        {
            PanelBlock.targetPanelBlock.CheckInput();
        }
        DestoyAllActionBlocks();
        targetBlock = null;
    }

    public bool NotSame(Block b)
    {
        if (b == null) return false;
        if (HorizontalSequence == b.HorizontalSequence)
        {
            if (VerticalSequence == b.VerticalSequence)
            {
                return false;
            }
            else
            {
                return true;
            }
        }
        else
        {
            return true;
        }
    }

    Object thisPanel = null;//Owner的Panel

    private void DisplayPanel()//展示Owner的Panel
    {
        Debug.Log("display panel");
        GameObject obj;
        if (thisPanel != null)
        {
            GameController gc = GameController.GetInstance();
            gc.blockDisplayingPanel = this;
            obj = Instantiate(thisPanel) as GameObject;
            gc.PanelOnDisplaying = obj;
        }
    }

    public void SetOccupantElement(MsgInBattle msg)//置入装备、技能要素卡
    {
        //很明显每个不同的子类需要不同的实现，所以比较复杂，尤其在接到消息后
    }

    Material DefaultMaterial;//= Resources.Load<Material>("");还是得写一下，或者干脆不同场景不同默认材质

    public void ClearBlock()
    {
        gameObject.GetComponent<Renderer>().material = DefaultMaterial;
        thisPanel = null;
        Owner = null;
        Card = null;
        IsEmpty = true;
        //清理数据
        if (infoBlock != null) ClearInfo();

        if (thisType == TargetType.Hand) HideBlock();
    }

    public void OccupantEnterBlock(TriggerAble t)
    {
        Owner = t;
        Owner.Territory = this;
        IsEmpty = false;
        thisPanel = Resources.Load(Owner.PanelPath, typeof(GameObject));
        gameObject.GetComponent<Renderer>().material = Resources.Load<Material>(Owner.MaterialPath);
        if (infoBlock != null) SetInfo(t.AttackPoint, t.HealthPoint);
        //当一个数据进入时，处理该数据，并加载该加载的fabs
    }

    public void HandEnterBlock(UnusedCard c)
    {
        Card = c;
        IsEmpty = false;
        gameObject.GetComponent<Renderer>().material = Resources.Load<Material>(Card.MaterialPath);
        //同理处理数据

        DisplayBlock();
    }

    bool IsEmpty = true;
    public bool GetIsEmpty()
    {
        return IsEmpty;
    }

    bool IsHiding = false;
    public void HideBlock()
    {
        IsHiding = true;
        transform.position = new Vector3(transform.position.x, transform.position.y, 101);
    }

    public void DisplayBlock()
    {
        IsHiding = false;
        transform.position = new Vector3(transform.position.x, transform.position.y, 99);
    }
    public bool GetIsHiding()
    {
        return IsHiding;
    }

    public InfoBlock infoBlock = null;

    public void SetInfo(int a, int b)
    {
        if (infoBlock != null)
        {
            infoBlock.SetText(a, b);
        }
    }

    public void ClearInfo()
    {
        if (infoBlock != null)
        {
            infoBlock.Clear();
        }
    }
}
