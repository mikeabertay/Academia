﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class EndTurnBtn : MonoBehaviour
{
    GameController gc = GameController.GetInstance();

    void Start()
    {
        Button b = GetComponent<Button>();
        b.onClick.AddListener(onClick);
        
    }

    public Text tx;

    void Update()
    {
        if(gc.MyCamp == gc.WhoseTurn)
        {
            tx.text = "回合结束";
        }
        else
        {
            tx.text = "对方回合";
        }
    }

    void onClick()
    {
        if (gc.MyCamp == gc.WhoseTurn)
        {/*
            MsgKernal msg = new MsgKernal();
            msg.mission = "endturn";
            SocketHelper sh = SocketHelper.GetInstance();
            sh.SendMessage(JsonUtility.ToJson(msg));
            Button b = GetComponent<Button>();*/

            MsgInBattle msg = new MsgInBattle();
            msg.mission = "battle";
            msg.effecterHorizontal = 0;
            msg.effecterVertical = 0;
            msg.msgNum = gc.GetHistory();
            SocketHelper sh = SocketHelper.GetInstance();
            sh.SendMessage(JsonUtility.ToJson(msg));


        }
    }



}
