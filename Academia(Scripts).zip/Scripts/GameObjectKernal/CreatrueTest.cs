﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TagPool;

public class CreatrueTest : TriggerAble
{
    GameController gc = GameController.GetInstance();

    public ActionDel CommonAttack;
    public ActionDel CommonMove;

    public void ICCommonAttack()
    {
        if (gc.target.thisType == Block.TargetType.Occupant)
        {
            if (ActionPoint > 0)
            {
                if (!gc.target.GetIsEmpty())
                {
                    if (gc.target.Owner.GetCanAttacked())
                    {
                        gc.SendBattleMsg();//发送消息
                        Debug.Log("没问题的");
                    }
                    else
                    {
                        FaultMsg.ThrowFaultMsg("该目标不可攻击");
                    }
                }
                else
                {
                    FaultMsg.ThrowFaultMsg("该区域无目标可攻击");
                }
            }
            else
            {
                FaultMsg.ThrowFaultMsg("行动力不足");
            }
        }
        else
        {
            FaultMsg.ThrowFaultMsg("请选择正确的攻击目标");
        }
    }

    public new int ActionPoint=2;

    public void HMCommonAttack(MsgInBattle msg)
    {

    }

    public void ICCommonMove()
    {

    }

    public void HMCommonMove(MsgInBattle msg)
    {

    }

    public new void Init()
    {
        Camp = 1;
        CommonAttack = new ActionDel("ActionBlock/Material/CommenAttack", ICCommonAttack, HMCommonAttack);
        CommonMove = new ActionDel("ActionBlock/Material/cMOV", ICCommonMove, HMCommonMove);

        PanelPath = "Panel/Hero/Hero2";

        MaterialPath = "r";
    }

    public CreatrueTest()
    {
        Init();
        AddAction(CommonAttack);
        
    }

    public override void CheckInput()
    {
        if (gc.controlnum != -1)
        {
            if (gc.controlnum < Actions.Count)
            {
                if (gc.MyCamp==gc.WhoseTurn)
                {
                    ActionDel ad = Actions[gc.controlnum] as ActionDel;
                    ad.ActionInputCheck();
                }
                else
                {
                    FaultMsg.ThrowFaultMsg("回合外不能进行操作");
                }
            }
           else
           {
                FaultMsg.ThrowFaultMsg("操作数异常");
           }
        }
        else
        {
            FaultMsg.ThrowFaultMsg("请选择行动");
        }
    }

    public override void HandleMsg(MsgInBattle msg)
    {

    }

    public override void SetElement(UnusedCard uc,MsgInBattle msg)//unused card调用
    {
        //根据实际情况实现，根据additional num不同设置不同的元素，要进行类型转换（as）
        //被unused card操作数1调用

        //！！！应修改为abstract和override
    }

    public UnusedCard magicscoll = new CardTest();

    public override UnusedCard GetElement(int num)//panel调用
    {
        if (num == 0) return new UnusedCard(MaterialPath, null);
        if (num == 3) return magicscoll;

        //其他元素数据的情况仍需要找到对应编号的Material
        return null;
    }

}
