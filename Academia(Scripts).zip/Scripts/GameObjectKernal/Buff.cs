﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Buff
{
    public bool IsDebuff = false;

    public TriggerAble Buffer;

    public Buff()
    {
        GetBuff = FuncGetBuff;
        EndBuff = FuncEndBuff;
    }

    public Buff(TriggerAble buffer, bool isdebuff, GetBuffDel funcget, EndBuffDel funcend)
    {
        IsDebuff = isdebuff;
        Buffer = buffer;
        GetBuff = funcget;
        EndBuff = funcend;
    }

    public delegate void GetBuffDel();
    public GetBuffDel GetBuff;
    public void FuncGetBuff()
    {

    }

    public delegate void EndBuffDel();
    public EndBuffDel EndBuff;
    public void FuncEndBuff()
    {

    }
}