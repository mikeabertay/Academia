﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class InfoBlock : MonoBehaviour
{
    void Start()
    {
        atk.text = "";
        hp.text = "";
    }

    void Update()
    {

    }

    public TextMesh atk;
    public TextMesh hp;

    public void SetText(int a, int h)
    {
        atk.text = a.ToString();
        hp.text = h.ToString();

    }

    public void Clear()
    {
        atk.text = "";
        hp.text = "";
    }
}
