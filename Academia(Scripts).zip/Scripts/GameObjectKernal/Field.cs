﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Field : MonoBehaviour
{

    GameController gc = GameController.GetInstance();


    void Start()
    {
    }

    void Update()
    {

    }

    void OnMouseUp()
    {
        gc.ClearInput();
    }
    public Field()
    {
        gc.BattleField = this;


        //--------------父类委托的保险处理---------------------
        FindNextBlock = FuncFindNextTo;
        FindNearbyBlock = FuncFindNearBy;

        CalculateDistance = FuncCalDis;

        DispatchCards = FuncDispatch;

        SetHeroesIntoScene = FuncSetHeroes;

    }

    public delegate Block[] FindBlocks(Block b);

    public FindBlocks FindNextBlock;//找相邻，需要子类实现

    public FindBlocks FindNearbyBlock;//找周围，需要子类实现

    public Block[] FuncFindNextTo(Block b)
    {
        return null;
    }

    public Block[] FuncFindNearBy(Block b)
    {
        return null;
    }

    public delegate int CalDis(Block b1, Block b2);
    public CalDis CalculateDistance;//计算格子间的距离，每个场景可能有所不同

    public int FuncCalDis(Block b1, Block b2)
    {
        return -1;
    }

    public Block[] HandBlocks;//所有数组的0都要空出来
    public Block[] OccupantBlocks;
    public Block[] MechBlocks;

    public void ClearAllBlocks()
    {
        foreach(Block b in HandBlocks)
        {
            if (b != null) b.ClearBlock();
        }
        foreach (Block b in OccupantBlocks)
        {
            if (b != null) b.ClearBlock();
        }
        foreach (Block b in MechBlocks)
        {
            if (b != null) b.ClearBlock();
        }
    }

    public void SetHandHorizontalNum(int camp)
    {
        foreach (Block b in HandBlocks)
        {
            b.HorizontalSequence = -1 * camp;
        }
    }

    public Material BlockDefaultMaterial;//block的默认材质，不同场景做不同处理

    public delegate void DispatchFuncUseInt(int leavenum);
    public DispatchFuncUseInt DispatchCards;//调度手牌block，在使用手牌后调度

    public void FuncDispatch(int leavenum)//1-handmax
    {
        if (leavenum == gc.MyHand)
        {
            HandBlocks[leavenum - 1].ClearBlock();

        }
        else
        {
            for (int i = leavenum; i < HandMax; i++)
            {
                if (HandBlocks[i].Card != null)
                {
                    HandBlocks[i - 1].HandEnterBlock(HandBlocks[i].Card);
                    HandBlocks[i].ClearBlock();
                }
            }
        }

    }

    public delegate void SetHeroesDel(HeroController hc);

    public SetHeroesDel SetHeroesIntoScene;

    public void FuncSetHeroes(HeroController hc)//很明显每个场景英雄入场的规则不同
    {

    }

    public Block FindOccupantBlock(int hori, int vert)
    {
        foreach (Block b in OccupantBlocks)
        {
            if (b != null)
            {
                if (b.HorizontalSequence == hori)
                {
                    if (b.VerticalSequence == vert)
                    {
                        return b;
                    }
                }
            }
        }
        return null;
    }

    public Block FindHandBlock(int num)
    {
        return HandBlocks[num - 1];
    }

    public int HandMax = 10;

    public void StartGameDraw()
    {
        for (int i = 0; i < 5; i++)
        {
            gc.DrawCard(1);
            gc.DrawCard(2);
        }
    }

    public void StartGameBuildUpDeck(int[] a)
    {
        /*正常构造卡组
        foreach(int i in a)
        {
            
        }*/

        ////////////////////////试玩版构造卡组/////////////////////////
        //gc.MyDeck.Add(new CardTest());
        for (int i = 0; i < 10; i++)
        {
            gc.MyDeck.Add(new Card1());
            gc.MyDeck.Add(new Card2());
            gc.MyDeck.Add(new Card3());
        }

        ////////////////////////试玩版构造卡组/////////////////////////


    }

    public UnusedCard IntToCard(int a)
    {
        switch (a)
        {
            case 1:
                return new Card1();
            case 2:
                return new Card2();
            case 3:
                return new Card3();
            default:
                return null;
        }
    }

    public void SetOccupantIntoScene(TriggerAble t, int hori, int vert)
    {
        Block b = FindOccupantBlock(hori, vert);
        if (b != null)
        {
            b.OccupantEnterBlock(t);
            gc.OccupantList.Add(t);
        }
    }
}
