﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class UnusedCard
{
    public bool IsSelectTargetEffect;

    public delegate void Check();
    public Check CheckInput;

    public delegate void Handle(MsgInBattle msg);
    public Handle HandleMsg;

    public void FunctionHandle(MsgInBattle msg)
    {

    }

    public void FunctionCheck()
    {
        //处理state
        //相关的动画
    }


    public string MaterialPath;

    public string WholePicturePath;

    public UnusedCard()
    {
        CheckInput = FunctionCheck;
        HandleMsg = FunctionHandle;
    }

    public UnusedCard(string matPath, string picPath)//简单传参的工具
    {
        MaterialPath = matPath;
        WholePicturePath = picPath;
    }


    public int CardNum = 0;//方便创建与处理消息，以及构造消息

    public int StateNum = 0;//卡牌有不同的状态，每个数值对应不同状态，具体的数值由子类封装并处理
    //目前考虑的是质数的整数倍，不同质数代表不同状态，可以整除则代表具有某个状态，需要判断不为零
}
