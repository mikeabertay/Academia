﻿//using System.Collections;
//using System.Collections.Generic;
//using UnityEngine;
//using TagPool;
//using System.Reflection;
//using System;

//public class CardA : TriggerAble, IAnimalTag, IPlantTag
//{

//    //// Start is called before the first frame update
//    //void Start()
//    //{
//    //    ObjectType = "plant";
//    //    Test();

//    //}

//    CardA a;

//    //// Update is called once per frame
//    //void Update()
//    //{
//    //    /*    if (a == null) a = this;
//    //        TriggerAble b = a ;
//    //        IPlantTag i = a as IPlantTag;
//    //        IAnimalTag aa = b as IAnimalTag;
//    //        if (i != null) i.PlantGrowUp();
//    //        else Debug.Log("没找到");
//    //        //////类型转换用as关键字,调用之前判断一下
//    //        */

//    //}


//    public void Test()
//    {
//        a = this;
//        CardA b = new CardA();
//        ArrayList al = new ArrayList();
//     //   al.Add(b);

//        al.Add(a);
//        Debug.Log(al[0]);

//        //  al.Remove(a);
//        //Destroy(this);
//        /*      Debug.Log(al.Count);
//              Debug.Log(al[0]);*/

//        Debug.Log( "inde="+al.IndexOf(b));

//    }

//    public new void StartGame()
//    {
//        Debug.Log("this is son");
//    }

//    public void PlantGrowUp()
//    {
//        Debug.Log("this is a plant");
//    }
//    public void AnimalDoSomething()
//    {
//        Debug.Log("this is an animal");

//    }
//    public override void CheckInput()
//    {
//        throw new NotImplementedException();
//    }

//    public override void HandleMsg(MsgInBattle msg)
//    {
//        throw new NotImplementedException();
//    }

//    public override UnusedCard GetElement(int num)
//    {
//        throw new NotImplementedException();
//    }
//}
