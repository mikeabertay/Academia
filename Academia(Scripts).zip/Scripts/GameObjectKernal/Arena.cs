﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Arena : Field
{
    private void Awake()
    {
        SetHeroesIntoScene = FuncSetHeroes;

        GameController gc = GameController.GetInstance();
        gc.BattleField = this;
    }

    void Start()
    {
        //BlockDefaultMaterial = Resources.Load<Material>("Scene/Arena/ArenaDefault");
        GameController gc = GameController.GetInstance();
        gc.BattleField = this;
    }




    void Update()
    {
        GameController gc = GameController.GetInstance();
        gc.BattleField = this;

    }

    void OnMouseUp()
    {
        GameController gc = GameController.GetInstance();
        gc.ClearInput();
    }

    public Arena()
    {
        SetHeroesIntoScene = FuncSetHeroes;
        GameController gc = GameController.GetInstance();
        gc.BattleField = this;

    }

    public new void FuncSetHeroes(HeroController hc)
    {
        GameController gc = GameController.GetInstance();

        if (hc.thisCamp == 1)
        {
            Block b = FindOccupantBlock(2, 1);//先手的第一个英雄设置在2.1，其他所有英雄都不入场
            Hero h;
            if (hc.heroList.Count > 0)
            {
                h = hc.heroList[0] as Hero;
                if (h != null)
                {
                    b.OccupantEnterBlock(h);
                    gc.OccupantList.Add(h);
                    if (gc.MyCamp == 1) AnimeFactory.GetInstance().DisplaySpotLight(b.transform);
                }
            }

        }

        else if (hc.thisCamp == 2)
        {
            Block b = FindOccupantBlock(2, 3);//后手2.3
            Hero h;
            if (hc.heroList.Count > 0)
            {
                h = hc.heroList[0] as Hero;
                if (h != null)
                {
                    b.OccupantEnterBlock(h);
                    gc.OccupantList.Add(h);
                    if (gc.MyCamp == 2) AnimeFactory.GetInstance().DisplaySpotLight(b.transform);
                }
            }
        }

        if (hc.heroList.Count > 1)
        {
            hc.heroList.RemoveRange(1, hc.heroList.Count - 1);
            //当某一方的初始英雄数超过1人时，播一段专属的台词
        }
    }


}
