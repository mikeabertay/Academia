﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace TagPool
{

    public interface IPlantTag
    {
        void PlantGrowUp();
    }

    public interface IAnimalTag
    {
        void AnimalDoSomething();
    }

    public interface IMagicScollTag
    {
        void MagicEffect();
    }
    //------------------------装备标签---------------------------
    public interface IEquipmentTag
    {

    }

    public interface IWeaponTag : IEquipmentTag
    {
        void Disarm();
        void Poison();
    }

    public interface ICorsletTag : IEquipmentTag
    {

    }

    public interface IAccessoryTag : IEquipmentTag
    {

    }

    public interface ISwordTag : IWeaponTag
    {

    }

    public interface IShieldTag : IWeaponTag
    {

    }

    public interface IItemTag
    {

    }

    //------------------------英雄标签---------------------------
    public interface IMagicianTag
    {
        void UseScoll();
    }

}
