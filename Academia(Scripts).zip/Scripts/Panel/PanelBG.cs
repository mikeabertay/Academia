﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PanelBG : MonoBehaviour
{
    void Start()
    {
        GameController gc = GameController.GetInstance();

        if (gc.blockDisplayingPanel.Owner.Camp==0)
        {
            bgMaterial = neutralMaterial;
        }
        else 
        {
            if(gc.blockDisplayingPanel.Owner.Camp != gc.MyCamp)
            {
                bgMaterial = enemyMaterial;
            }
            else
            {
                bgMaterial = allyMaterial;
            }
        }

        gameObject.GetComponent<Renderer>().material = Resources.Load<Material>(bgMaterial);

    }

    string allyMaterial = "Panel/Default/Ally";
    string enemyMaterial = "Panel/Default/Enemy";
    string neutralMaterial = "Panel/Default/Neutral";
    string bgMaterial;

    void Update()
    {
        
    }

    public PanelBlock[] blocks;

    public void Refresh()
    {
        foreach(PanelBlock b in blocks)
        {
            b.Refresh();
        }
    }
}
