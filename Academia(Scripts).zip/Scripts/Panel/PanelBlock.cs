﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TagPool;
using System;

public class PanelBlock : MonoBehaviour
{
    public enum PanelBlockType//类型根据不同，每次修改
    {
        cardpicture,
        IMagicScollTag,
        IEquipmentTag,
        IWeaponTag,
        ICorsletTag,
        IAccessoryTag,
        ISwordTag,
        IShieldTag,
        IItemTag,
    }

    String TypeString = "TagPool.";

    public PanelBlockType panelBlockType;

    void Start()
    {
        TypeString += panelBlockType.ToString();

        //取数据，然后根据取得的数据设置Material
        Refresh();
    }

    void Update()
    {

    }

    public PanelBlock()
    {
        CheckInput = FunctionCheck;
    }

    public int Num;//块的编号，对应每个卡牌的相同编号元素，每次修改

    public static PanelBlock targetPanelBlock = null;

    void OnMouseEnter()
    {
        targetPanelBlock = this;
    }

    void OnMouseExit()
    {
        targetPanelBlock = null;
    }

    public delegate void CheckElement();
    public CheckElement CheckInput;

    [HideInInspector]
    public UnusedCard thisCard = null;//在refresh的时候从triggerable里拉取（GetElement），如果null则说明没有，可以响应输入，否则不响应输入
    //另一种写法是引用一次unused card，这样可以获取更多信息！！！！！

    public void FunctionCheck()
    {

        if (Num > 0)//0为插画块，方便插画块刷新图标
        {
            GameController gc = GameController.GetInstance();
            //判断拉取的数据不为空，错误反馈“已有该类型的元素”
            if (gc.blockDisplayingPanel.Owner.GetElement(Num)==null)
            {
                if (gc.MyCamp == gc.WhoseTurn)
                {
                    if (gc.effecter != null)
                    {
                        if (gc.effecter.thisType == Block.TargetType.Hand)
                        {
                            if (gc.effecter.Card != null)
                            {
                                Type t = gc.effecter.Card.GetType();
                                if (System.Type.GetType(TypeString).IsAssignableFrom(t))
                                {
                                    //对了
                                    gc.target = gc.blockDisplayingPanel;
                                    gc.controlnum = 1;
                                    gc.additionalnum = Num;
                                    gc.quicknum = gc.effecter.Card.CardNum;
                                    gc.quickstate = gc.effecter.Card.StateNum;
                                    //gc.SendBattleMsg();
                                    gc.effecter.CheckInput();
                                    Debug.Log("啦啦啦");
                                }
                                else
                                {
                                    FaultMsg.ThrowFaultMsg("请放入正确类型的卡牌");
                                    gc.ClearInput();

                                }
                            }
                            else
                            {
                                FaultMsg.ThrowFaultMsg("请选择手牌");
                                gc.ClearInput();

                            }
                        }
                        else
                        {
                            FaultMsg.ThrowFaultMsg("请选择手牌");
                            gc.ClearInput();

                        }
                    }
                    else
                    {
                        FaultMsg.ThrowFaultMsg("请选择手牌");
                        gc.ClearInput();

                    }
                }
                else
                {
                    FaultMsg.ThrowFaultMsg("回合外不能置入");
                    gc.ClearInput();
                }
            }
            else
            {
                FaultMsg.ThrowFaultMsg("已经没位置放了");
                gc.ClearInput();
            }
        }
    }

    public void Refresh()
    {
        //取数据，刷新Material，调用GetElement
        //让panel调用一次refresh

        GameController gc = GameController.GetInstance();

        thisCard = gc.blockDisplayingPanel.Owner.GetElement(Num);

        if (thisCard != null)
        {
            if (thisCard.MaterialPath != null)
            {
                gameObject.GetComponent<Renderer>().material = Resources.Load<Material>(thisCard.MaterialPath);
            }
        }
    }

    void OnMouseDown()
    {
        if (thisCard != null)
        {
            if (thisCard.WholePicturePath != null)
            {
                GameController gc = GameController.GetInstance();
                gc.displayCard.Display(thisCard.WholePicturePath);
            }
        }
    }

}
