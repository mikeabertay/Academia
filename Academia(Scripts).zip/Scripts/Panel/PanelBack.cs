﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PanelBack : MonoBehaviour
{
    void Start()
    {
        
    }

    void Update()
    {
        
    }

    private void OnMouseUpAsButton()
    {
        GameController gc = GameController.GetInstance();
        Destroy(gc.PanelOnDisplaying);
    }
}
