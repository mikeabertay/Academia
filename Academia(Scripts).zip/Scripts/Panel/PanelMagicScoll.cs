﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TagPool;
using System;

public class PanelMagicScoll : PanelBlock
{
    void Start()
    {
        Type type = System.Type.GetType("TagPool.IPlantTag");
        if (type == typeof(IPlantTag))
        {
            Debug.Log("对了");
        }

    }

    void Update()
    {

    }

    public new void FunctionCheck()
    {
        GameController gc = GameController.GetInstance();
        if (gc.effecter != null)
        {
            if (gc.effecter.thisType == Block.TargetType.Hand)
            {
                if (gc.effecter.Card != null)
                {
                    Type t = gc.effecter.Card.GetType();
                    if (typeof(IMagicScollTag).IsAssignableFrom(t))
                    {
                        //对了
                        gc.target = gc.blockDisplayingPanel;
                        gc.controlnum = 1;
                        gc.additionalnum = Num;
                        // gc.SendBattleMsg();
                        Debug.Log("啦啦啦");
                    }
                    else
                    {
                        FaultMsg.ThrowFaultMsg("请放入魔法卷轴");
                        gc.ClearInput();

                    }
                }
                else
                {
                    FaultMsg.ThrowFaultMsg("请选择手牌");
                    gc.ClearInput();

                }
            }
            else
            {
                FaultMsg.ThrowFaultMsg("请选择手牌");
                gc.ClearInput();

            }
        }
        else
        {
            FaultMsg.ThrowFaultMsg("请选择手牌");
            gc.ClearInput();

        }
    }

    public PanelMagicScoll()
    {
        CheckInput = FunctionCheck;
    }
}