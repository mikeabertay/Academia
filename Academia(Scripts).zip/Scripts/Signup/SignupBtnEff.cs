﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class SignupBtnEff : MonoBehaviour
{
    void Start()
    {
        Button b = GetComponent<Button>();
        b.onClick.AddListener(onClick);
    }

    void Update()
    {
       /* if (accountController.SignupState == "signupsuccess")
        {
            accountController.SignupState = null;
            ErrorText.text = "SignupSuccess";
            //注册成功
            //SceneManager.LoadScene("Login");
        }
        else*/ if (accountController.LoginState != null)
        {
            ErrorText.text = accountController.LoginState;
            accountController.LoginState = null;

        }
    }

    private AccountController accountController = AccountController.GetInstance();

    public Text ErrorText;
    public InputField ID;
    public InputField psw;
    public InputField psw2;

    void onClick()
    {
        if (accountController.CanSignup)
        {
            //accountController.Signup(ID.text, psw.text, psw2.text);
        }
    }
}
