﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GlobalText : MonoBehaviour
{

    private static GlobalText globalText ;


    public static GlobalText GetInstance()
    {
        return globalText;
    }

    void Start()
    {
        DontDestroyOnLoad(gameObject);
        tm.text = "";
        globalText = this;
    }

    void Update()
    {
        if (tm.text != "") i++;
        if (i >= 150)
        {
            Hide();
        }
    }

    int i = 0;

    public TextMesh tm;

    public void DisplayFaultMsg(string str)
    {
        tm.text = str;
    }

    void Hide()
    {
        i = 0;
        tm.text = "";
    }
}
