﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MessageController : MonoBehaviour
{
    public GameObject go;
    public StrToMsg strToMsg = StrToMsg.GetInstance();
    public MsgToObj msgToObj = MsgToObj.GetInstance();

    void Start()
    {
        DontDestroyOnLoad(go);
    }

    void Update()
    {
        strToMsg.Update();
        msgToObj.Update();


    }
}
