﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class GlobalController : MonoBehaviour
{
    public MatchHelper matchHelper = MatchHelper.GetInstance();
    public AccountController accountController = AccountController.GetInstance();

    

    private string version= "v0.1test";

    //public string scene = "";

    public bool CheckVersion(string versionFromServer)
    {
        if (version == versionFromServer) return true;
        else
        {
            SceneManager.LoadScene("WrongVersion");
            return false;
        }
    }

    void Start()
    {
        StrToMsg strToMsg = StrToMsg.GetInstance();
        strToMsg.setGC(this);
        accountController.setGC(this);

        GameController gc =  GameController.GetInstance();
        gc.MyCamp = 1;
        gc.WhoseTurn = 1;
    }

    void Update()
    {
        
    }
}
