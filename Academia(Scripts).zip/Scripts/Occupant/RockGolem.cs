﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RockGolem : TriggerAble
{
    public override void CheckInput()
    {
        if (gc.controlnum != -1)
        {
            if (gc.controlnum < Actions.Count)
            {
                if (gc.MyCamp == gc.WhoseTurn)
                {
                    ActionDel ad = Actions[gc.controlnum] as ActionDel;
                    ad.ActionInputCheck();
                }
                else
                {
                    FaultMsg.ThrowFaultMsg("回合外不能进行操作");
                }
            }
            else
            {
                FaultMsg.ThrowFaultMsg("操作数异常");
            }
        }
        else
        {
            FaultMsg.ThrowFaultMsg("请选择行动");
        }
    }

    public override void HandleMsg(MsgInBattle msg)
    {
        if (msg.controlNum < Actions.Count && msg.controlNum >= 0)
        {
            ActionDel ad = Actions[msg.controlNum] as ActionDel;
            ad.ActionHandleMsg(msg);
        }
    }

    public override UnusedCard GetElement(int num)
    {
        return null;
    }

    public override void SetElement(UnusedCard uc, MsgInBattle msg)
    {

    }
    GameController gc = GameController.GetInstance();


    public RockGolem(int camp)
    {
        Camp = camp;

        ActionPoint = 0;

        HealthPoint = 20;
        AttackPoint = 4;

        Init();
        AddAction(CommonAttack);


        GetDamage = FuncGetDamage;
        StartTurn = FuncStartTurn;
    }

    public new void Init()
    {
        CommonAttack = new ActionDel("ActionBlock/Material/CommenAttack", ICCommonAttack, HMCommonAttack);

        PanelPath = "Panel/Occupant/RockGolem";

        MaterialPath = "Picture/Occupant/RockGolem";
    }


    public ActionDel CommonAttack;

    public void ICCommonAttack()
    {
        if (gc.target.thisType == Block.TargetType.Occupant)
        {
            if (ActionPoint > 0)
            {
                if (!gc.target.GetIsEmpty())
                {
                    if (gc.target.Owner.GetCanAttacked())
                    {
                        gc.SendBattleMsg();//发送消息
                        Debug.Log("没问题的");
                    }
                    else
                    {
                        FaultMsg.ThrowFaultMsg("该目标不可攻击");
                    }
                }
                else
                {
                    FaultMsg.ThrowFaultMsg("该区域无目标可攻击");
                }
            }
            else
            {
                FaultMsg.ThrowFaultMsg("行动力不足");
            }
        }
        else
        {
            FaultMsg.ThrowFaultMsg("请选择正确的攻击目标");
        }
    }

    public void HMCommonAttack(MsgInBattle msg)
    {
        if (msg.targetHorizontal >= 0)
        {
            Block b = gc.BattleField.FindOccupantBlock(msg.targetHorizontal, msg.targetVertical);
            TriggerAble t = b.Owner;
            if (t != null)
            {
                ActionPoint--;
                t.GetAttackedBy(this);
                if (!BreakOffState) t.GetDamage(AttackPoint, 0);
            }
        }
    }


    public new void FuncGetDamage(int pysical, int magical)
    {


        HealthPoint -= pysical + magical;
        if (pysical > 0) AnimeFactory.GetInstance().DisplayDamageText(pysical, Territory.transform);
        if (magical > 0) AnimeFactory.GetInstance().DisplayDamageText(magical, Territory.transform);
        if (HealthPoint <= 0)
        {
            BreakOffState = true;
            gc.OccupantList.Remove(this);
            Territory.ClearBlock();
        }
    }


    public new void FuncStartTurn()
    {
        ActionPoint = 1;
    }

}
