﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class TestBtn : MonoBehaviour
{
    void Start()
    {
        Button b = GetComponent<Button>();
        b.onClick.AddListener(onClick);
    }

    void Update()
    {
        
    }

    public Text a;

    bool CanClick = true;
    void onClick()
    {
        if (CanClick)
        {
            SocketHelper sh = SocketHelper.GetInstance();
            MsgKernal msg = new MsgKernal();
            msg.mission = "test";
            string str = JsonUtility.ToJson(msg);
            sh.SendMessage(str);
            a.text = "正在匹配";
            CanClick = false;
        }
    }
}
