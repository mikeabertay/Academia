﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class PreSceneBlock : MonoBehaviour
{
    void Start()
    {
        
    }

    void Update()
    {
        SceneManager.LoadScene("TestScene");
    }
}
