﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MsgToObj
{
    private static MsgToObj msgToObj = new MsgToObj();

    public static ArrayList GQueue = new ArrayList();

    public static MsgToObj GetInstance()
    {
        return msgToObj;
    }

    public void AddToQueue(object obj)
    {
        GQueue.Add(obj);
    }

    GameController gc = GameController.GetInstance();

    int i = 0;
    public void Update()
    {
        if (gc.ReadyToBuild)
        {
            if (i > 3)
            {
                gc.BuildUpGameInScene();
                gc.ReadyToBuild = false;
                i = 0;
                return;
            }
            else
            {
                i++;
            }
        }
        MsgInBattle msg = null;
        if (GQueue.Count > 0) msg = GQueue[0] as MsgInBattle;
        GQueue.Remove(msg);

        //如果有（对战中的）权限就处理该msg
        if (authority)
        {
            if (msg != null)
            {
                if (msg.msgNum == gc.GetHistory())
                {
                    gc.AddHistory(msg);
                    Debug.Log(JsonUtility.ToJson(msg));//这里处理逻辑

                    if (msg.effecterHorizontal > 0)//版图内的物体
                    {
                        Block b = gc.BattleField.FindOccupantBlock(msg.effecterHorizontal, msg.effecterVertical);
                        b.Owner.HandleMsg(msg);
                    }

                    else if (msg.effecterHorizontal == 0)//特殊处理（包括Mech）
                    {
                        if (msg.effecterVertical == 0)//回合结束处理
                        {
                            foreach (object o in gc.OccupantList)
                            {
                                TriggerAble t = o as TriggerAble;
                                if (t != null) t.EndTurn();
                            }

                            gc.WhoseTurn = 3 - gc.WhoseTurn;
                            if (gc.WhoseTurn == gc.MyCamp) FaultMsg.ThrowFaultMsg("你的回合");
                            else FaultMsg.ThrowFaultMsg("对方回合");
                            //if (gc.WhoseTurn == 1) gc.WhoseTurn = 2;
                            //else if (gc.WhoseTurn == 2) gc.WhoseTurn = 1;
                            gc.TurnNum++;
                            foreach(object o in gc.OccupantList)
                            {
                                TriggerAble t = o as TriggerAble;
                                if (t != null) t.StartTurn();
                            }
                            
                        }
                        else { }
                    }
                    else if (msg.effecterHorizontal < 0)//手牌效果
                    {
                        if (msg.effecterHorizontal == -1 * gc.MyCamp)
                        {
                            gc.BattleField.DispatchCards(msg.effecterVertical);
                            gc.MyHand--;
                        }
                        else
                        {
                            gc.OpHand--;
                        }

                        UnusedCard uc = gc.BattleField.IntToCard(msg.quicknum);
                        uc.HandleMsg(msg);

                        if (gc.PanelOnDisplaying != null) gc.PanelOnDisplaying.GetComponent<PanelBG>().Refresh();

                    }

                    gc.GameOverDicision();//例行公事，检查是否游戏结束
                }
            }
        }
    }

    bool authority = true;
}
