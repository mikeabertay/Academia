﻿using System;
using System.Collections;
using System.Collections.Concurrent;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class StrToMsg
{
    private static StrToMsg strToMsg = new StrToMsg();

    public static ConcurrentQueue<string> CQueue = new ConcurrentQueue<string>();

    public static StrToMsg GetInstance()
    {
        return strToMsg;
    }

    private GlobalController gc;
    public void setGC(GlobalController globalController)
    {
        gc = globalController;
    }

    private StrToMsg()
    {

    }



    public void Update()
    {

        if (!CQueue.IsEmpty)
        {
            string msg;
            CQueue.TryDequeue(out msg);
            Handle(msg);//具体的没写完

        }
    }

    private void Handle(string msg)
    {

        string Mission = JsonUtility.FromJson<MsgKernal>(msg).mission;
    
        if (Mission != null)
        {
            Debug.Log(Mission);
            if (Mission == "connect"|| Mission == "testconnect")//连接返送的消息 
            {
                MsgConnect obj = JsonUtility.FromJson<MsgConnect>(msg);
                //Debug.Log(obj.announcement);
                gc.CheckVersion(obj.version);//检查版本

            }
            else if (Mission == "loginsuccess")//登陆成功的消息
            {
                AccountController accountController = AccountController.GetInstance();
                accountController.LoginState = "登录成功";
                MsgLoginSuccess obj = JsonUtility.FromJson<MsgLoginSuccess>(msg);
                //登录成功后的状态处理

                //要构造数据并跳转对应场景
            }
            else if (Mission == "loginfail")//对战中的消息
            {
                MsgLoginFail obj = JsonUtility.FromJson<MsgLoginFail>(msg);
                AccountController accountController = AccountController.GetInstance();
                if (obj.errormsg == "idorpswwrong")
                {
                    accountController.LoginState = "用户名或密码错误";
                }
                else
                {
                    accountController.LoginState = "未知错误";

                }


            }
            else if (Mission == "battle")//对战中的消息
            {
                MsgToObj msgToObj = MsgToObj.GetInstance();

                MsgInBattle obj = JsonUtility.FromJson<MsgInBattle>(msg);

                msgToObj.AddToQueue(obj);
            }
            else if (Mission == "buildup")//构建对局的消息
            {
                MsgBuildGame obj = JsonUtility.FromJson<MsgBuildGame>(msg);

                BuildUpController bc = BuildUpController.GetInstance();

                bc.RecieveMsgBuildUp(obj);
            }
            else if (Mission == "choosehero")//英雄选择的消息
            {
                MsgHeroChoose obj = JsonUtility.FromJson<MsgHeroChoose>(msg);

                BuildUpController bc = BuildUpController.GetInstance();

                bc.RecieveOneChoose(obj);
            }

            else if (Mission == "drop")//游戏强制结束的消息
            {
                MatchHelper mh = MatchHelper.GetInstance();
                mh.ClearAfterMatch();
                GameController gc = GameController.GetInstance();
                gc.ClearThisBattle();
                BuildUpController bc = BuildUpController.GetInstance();
                bc.ClearWhenGaming();
                SceneManager.LoadScene("MainScene");
                FaultMsg.ThrowFaultMsg("对方掉线了");

            }

            else if (Mission == "rebuild")//重新构建的消息
            {

                //如果接到了空的buildupmsg，那就再登录一次，空的情况只出现在自己为1且2未选时
                //非空则构建
            }


            else if (Mission == "testbuild")//在试玩模式下构建的消息
            {
                GameController gameController = GameController.GetInstance();
                gameController.WhoseTurn = 1;
                gameController.IsInBattle = true;

                //导入数据
                MsgTestBuild obj = JsonUtility.FromJson<MsgTestBuild>(msg);
                gameController.SetRandomList(obj.randomlist);
                 gameController.MyCamp = obj.mycamp;

                //跳场景不细写了
                int scene = obj.scene;
                if (true) SceneManager.LoadScene("Arena");

                gameController.ReadyToBuild = true;
                //gameController.BuildUpGameInScene();
            }

            else if (Mission == "testfinish")//在试玩模式下游戏结束的消息
            {

                SceneManager.LoadScene("TestScene");
                GameController gameController = GameController.GetInstance();
                gameController.ClearThisBattle();
            }
            else if (Mission == "endturn")//回合结束的消息
            {
                GameController gameController = GameController.GetInstance();
                if (gameController.WhoseTurn == 1) gameController.WhoseTurn = 2;
                else if (gameController.WhoseTurn == 2) gameController.WhoseTurn = 1;
            }

            else if (Mission == "testdrop")//测试模式下游戏强制结束的消息
            {
                GameController gc = GameController.GetInstance();
                gc.ClearThisBattle();
                SceneManager.LoadScene("TestScene");
                FaultMsg.ThrowFaultMsg("一名玩家掉线了");

            }

            else
            {

                Debug.Log("被屏蔽的JSON消息");//预期外的json串，屏蔽掉

            }
        }
    }
}
