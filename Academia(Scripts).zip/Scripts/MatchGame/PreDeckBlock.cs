﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//有输入
public class PreDeckBlock : MonoBehaviour//显示预选卡组的cube，是view和input部分，需挂载
{
    PreDeck deck;
    public int ID;
    public TextMesh textMesh;

    void Start()
    {
        DeckManager d = DeckManager.GetInstance();
        deck = d.GetDeck(ID);
        gameObject.GetComponent<Renderer>().material = HeroTexturePainter.PaintHeroTex(deck.hero);
        if (!deck.CanUse()) { //不可用的卡组变暗
            gameObject.GetComponent<Renderer>().material.color = new Color(0.2f, 0.2f, 0.2f);
        }
        textMesh.text = deck.name;
    }

    void Update()
    {
        
    }

    void AddDeck()//点击时添加卡组的回调
    {
        if (deck.CanUse())
        {
            MatchHelper m = MatchHelper.GetInstance();
            m.AddDeck(deck);

        }
        else FaultMsg.ThrowFaultMsg("卡组不符合规定");
    }

    private void OnMouseUpAsButton()
    {
        AddDeck();
    }

    public void ChangeDeck()//获取的外部卡组集分页显示，用于换页时更换卡组，暂不实现
    {

    }
}
