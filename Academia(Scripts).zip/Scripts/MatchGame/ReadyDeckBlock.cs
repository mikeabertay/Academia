﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//有输入
public class ReadyDeckBlock : MonoBehaviour//显示选中卡组的cube，是view和input部分，需挂载
{
    PreDeck deck;
    public int ID;//需标注
    Material defaultMaterial;
    MatchHelper m = MatchHelper.GetInstance();
    public TextMesh textMesh;

    void Start()
    {
        defaultMaterial = HeroTexturePainter.PaintHeroTex(0);
        gameObject.GetComponent<Renderer>().material = defaultMaterial;
    }

    void Update()
    {
        PreDeck a;
        if (ID == 1) a = m.Deck1;
        else if (ID == 2) a = m.Deck2;
        else if (ID == 3) a = m.Deck3;
        else a = null;
        if (deck == null||deck!=a)//每帧检测是否需要加卡组
        {
            deck = m.GetDeck(ID);
            if (deck != null)
            {
                gameObject.GetComponent<Renderer>().material = HeroTexturePainter.PaintHeroTex(deck.hero);
                textMesh.text = deck.name;
            }
            else
            {
                gameObject.GetComponent<Renderer>().material = defaultMaterial;
                textMesh.text = "";

            }
        }

    }


    public void CancelDeck()//被点击时去除卡组的回调
    {
        m.CancelDeck(ID);
        gameObject.GetComponent<Renderer>().material = defaultMaterial;
        deck = null;
        textMesh.text = "";
    }

    private void OnMouseUpAsButton()
    {
        if (deck != null) CancelDeck();
        else FaultMsg.ThrowFaultMsg("请添加卡组");
    }
}
