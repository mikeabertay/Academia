﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class MatchBtn : MonoBehaviour
{

    BuildUpController bc;
    

    void Start()
    {
        Button b = GetComponent<Button>();
        b.onClick.AddListener(onClick);
        bc =  BuildUpController.GetInstance();
    }

    void Update()
    {
        if (bc.IsBuildingUp) {
            bc.IsBuildingUp = false;
            SceneManager.LoadScene("MatchSuccess");
        }
    }

    void onClick()
    {

        MatchHelper mh = MatchHelper.GetInstance();
        if(mh.CanInput) {
            if (mh.GetDeckNum() == 3)
            {
                mh.SendMessageForMatch();
                bc.SetDecks(mh.Deck1, mh.Deck2, mh.Deck3);
                // mh.ClearAfterMatch();//等接到匹配成功消息后再clear
                mh.CanInput = false;
            }
        }
    }
}
