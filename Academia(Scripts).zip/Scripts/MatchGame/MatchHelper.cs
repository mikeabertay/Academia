﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MatchHelper //match控制器，用于控制对局开始前的卡组选择，写得真烂
{
    private static MatchHelper matchHelper = new MatchHelper();


    public static MatchHelper GetInstance()
    {
        return matchHelper;
    }


    public PreDeck Deck1;
    public PreDeck Deck2;
    public PreDeck Deck3;


    int deckNum = 0;

    public int GetDeckNum()
    {
        return deckNum;
    }

    //Global持续调用的函数，可有可无
    public void Update()
    {
        
    }

    public bool CanInput = true;

    //发match消息
    public void SendMessageForMatch()
    {
        MsgMatchGame msg=new MsgMatchGame();
        msg.mission = "matchgame";
        msg.deck1 = Deck1.hero;
        msg.deck2 = Deck2.hero;
        msg.deck3 = Deck3.hero;
        msg.nickname = "";//注册或者主界面处理一下
        string str=JsonUtility.ToJson(msg);
        SocketHelper sh = SocketHelper.GetInstance();
        sh.SendMessage(str);
    }
    //游戏开始后调用，帮助清理内存，以便下次使用
    public void ClearAfterMatch()
    {
        Deck1 = null; Deck2 = null; Deck3 = null;
        deckNum = 0;
    }


    //与显示已选卡组block的互动
    public PreDeck GetDeck(int ID)
    {
        if (ID == 1)
        {
            return Deck1;
        }
        else if (ID == 2)
        {
            return Deck2;
        }
        else if (ID == 3)
        {
            return Deck3;
        }
        else return null;
    }

    public void CancelDeck(int ID)
    {
        if (ID == 1)
        {
            Deck1 = Deck2;
            Deck2 = Deck3;
            Deck3 = null;
            deckNum--;

        }
        else if (ID == 2)
        {
            Deck2 = Deck3;
            Deck3 = null;
            deckNum--;

        }
        else if (ID == 3)
        {
            Deck3 = null;
            deckNum--;

        }
    }

    //从预选卡组中加入卡组到匹配用卡组
    public void AddDeck(PreDeck deck)
    {
        //1.加入的卡组必须可用，已判断
        //2.加入的卡组英雄必须不与其他重复
        //3.只能加入三个卡组

        if (deckNum < 3)
        {
            if (deckNum == 0)
            {
                Deck1=new PreDeck(deck);
                deckNum++;
            }
            else if (deckNum == 1)
            {
                if (deck.GetHero()!=Deck1.GetHero())
                {
                    Deck2 = new PreDeck(deck);
                    deckNum++;
                }
                else
                {
                    FaultMsg.ThrowFaultMsg("不能选择重复的英雄");
                }
            }
            else if (deckNum == 2)
            {
                if (deck.GetHero() != Deck1.GetHero())
                {
                    if (deck.GetHero() != Deck2.GetHero())
                    {
                        Deck3 = new PreDeck(deck);
                        deckNum++;
                    }
                    else
                    {
                        FaultMsg.ThrowFaultMsg("不能选择重复的英雄");
                    }
                }
                else
                {
                    FaultMsg.ThrowFaultMsg("不能选择重复的英雄");
                }
            }
        }
        else
        {
            FaultMsg.ThrowFaultMsg("卡组数已达上限");
        }
       
    }

    //检查卡组可用性，调用时机需细想
    public bool CheckDeck()
    {
        return false;
    }
}
