﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class MainBtn : MonoBehaviour
{
    void Start()
    {
        Button b = GetComponent<Button>();
        b.onClick.AddListener(onClick);
    }

    void Update()
    {

    }

    void onClick()
    {
        MatchHelper mh = MatchHelper.GetInstance();
        if (mh.CanInput)
        {
            SceneManager.LoadScene("MainScene");
        }
    }
}
