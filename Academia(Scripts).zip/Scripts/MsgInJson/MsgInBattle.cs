﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[System.Serializable]
public class MsgInBattle : MsgKernal
{

    public int msgNum;//消息号，用于与历史进行校对
    public int effecterHorizontal;
    public int effecterVertical;
    public int targetHorizontal;
    public int targetVertical;
    public int controlNum;
    public int additionalNum;

    public int quicknum;//快速找到卡牌
    public int quickstate;
}
