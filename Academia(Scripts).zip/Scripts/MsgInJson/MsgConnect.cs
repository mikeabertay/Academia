﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[System.Serializable]
public class MsgConnect : MsgKernal
{
    public string version;
    public string connectstate;
    public string announcement;
}
