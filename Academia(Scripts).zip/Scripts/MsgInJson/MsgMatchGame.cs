﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[System.Serializable]
public class MsgMatchGame :MsgKernal
{
    public int deck1;
    public int deck2;
    public int deck3;

    public string nickname;


}
