﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[System.Serializable]
public class MsgBuildGame : MsgKernal
{
    public int mydeck1;
    public int mydeck2;
    public int mydeck3;
    public string mynickname;

    public int opdeck1;
    public int opdeck2;
    public int opdeck3;
    public string opnickname;

    public int scene;

    public int mycamp;//1先手2后手

    public int[] randomlist;

}
