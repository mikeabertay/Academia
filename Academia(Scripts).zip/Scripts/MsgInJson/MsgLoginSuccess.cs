﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[System.Serializable]
public class MsgLoginSuccess : MsgKernal
{
    public int table;
    public string state;
}
