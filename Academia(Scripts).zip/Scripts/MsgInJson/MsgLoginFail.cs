﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[System.Serializable]
public class MsgLoginFail : MsgKernal
{
    public string errormsg;
}
