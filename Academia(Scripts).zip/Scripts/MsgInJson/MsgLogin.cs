﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[System.Serializable]
public class MsgLogin : MsgKernal
{
    public string id;
    public string password;
}
