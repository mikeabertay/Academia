﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[System.Serializable]
public class MsgHeroChoose : MsgKernal
{
    public int hero;
    public int camp;
}
