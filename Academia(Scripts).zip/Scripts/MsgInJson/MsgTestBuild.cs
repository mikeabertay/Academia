﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[System.Serializable]
public class MsgTestBuild : MsgKernal
{
    public int mycamp;
    public int scene;
    public int[] randomlist;

}