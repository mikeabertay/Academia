﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Card1 : UnusedCard
{
    public Card1()
    {
        CardNum = 1;

        CheckInput = FunctionCheck;
        HandleMsg = FunctionHandle;

        MaterialPath = "Picture/Card/Card1";
        WholePicturePath = "Picture/CardPicture/c1";
    }

    public new void FunctionCheck()
    {
        GameController gc = GameController.GetInstance();

        if (gc.MyCamp == gc.WhoseTurn)
        {
            gc.controlnum = 1;
            gc.quicknum = CardNum;
            gc.SendBattleMsg();
        }
        else
        {
            FaultMsg.ThrowFaultMsg("回合外不能进行操作");
        }
    }



    public new void FunctionHandle(MsgInBattle msg)
    {
        GameController gc = GameController.GetInstance();
        if (msg.controlNum == 1)
        {
            if (msg.targetHorizontal >= 0)
            {
                Block b = gc.BattleField.FindOccupantBlock(msg.targetHorizontal, msg.targetVertical);
                if (!b.GetIsEmpty()) b.Owner.GetDamage(3, 0);
            }
        }
    }

}
