﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TagPool;

public class Card3 : UnusedCard, IMagicScollTag
{
    public Card3()
    {
        CardNum = 3;

        CheckInput = FunctionCheck;
        HandleMsg = FunctionHandle;

        MaterialPath = "Picture/Card/Card3";
        WholePicturePath = "Picture/CardPicture/c3";

        magicAction = new ActionDel("Picture/Card/Card3", ActionInputCheck, ActionHandleMsg);
    }

    public new void FunctionCheck()
    {
        GameController gc = GameController.GetInstance();

        if (gc.controlnum == 1)//装备时
        {
            gc.SendBattleMsg();//检查无误后发送
        }
        else//暂时没有，但是也得清
        {
            gc.ClearInput();
        }
    }

    public new void FunctionHandle(MsgInBattle msg)
    {
        GameController gc = GameController.GetInstance();

        if (msg.controlNum == 1)
        {
            Block b = gc.BattleField.FindOccupantBlock(msg.targetHorizontal, msg.targetVertical);
            if (b != null) magician = b.Owner;
            if (magician != null)
            {
                magician.SetElement(this, msg);
                magician.AddAction(magicAction);
            }
        }
    }

    TriggerAble magician;
    ActionDel magicAction;

    public void ActionInputCheck()
    {
        GameController gc = GameController.GetInstance();

        if (gc.target.thisType == Block.TargetType.Occupant)
        {

            if (magician.ActionPoint > 0)
            {
                if (gc.target.GetIsEmpty())
                {
                    gc.SendBattleMsg();//发送消息
                    Debug.Log("没问题的");
                }
                else
                {
                    FaultMsg.ThrowFaultMsg("该区域已被占领");
                }
            }
            else
            {
                FaultMsg.ThrowFaultMsg("行动力不足");
            }
        }
        else
        {
            FaultMsg.ThrowFaultMsg("请选择正确的施法目标");
        }
    }
    public void ActionHandleMsg(MsgInBattle msg)
    {
        GameController gc = GameController.GetInstance();
        if (msg.targetHorizontal > 0)
        {
            Block b = gc.BattleField.FindOccupantBlock(msg.targetHorizontal, msg.targetVertical);
            if (b.GetIsEmpty())
            {
                magician.ActionPoint--;

                RockGolem r = new RockGolem(magician.Camp);
                b.OccupantEnterBlock(r);
                gc.BattleField.SetOccupantIntoScene(r, msg.targetHorizontal, msg.targetVertical);

                magician.RemoveAction(magicAction);

                IMagicianTag m = magician as IMagicianTag;
                if (m != null) m.UseScoll();
            }
        }
    }

    public void MagicEffect()
    {

    }


}
