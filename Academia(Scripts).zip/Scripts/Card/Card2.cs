﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TagPool;

public class Card2 : UnusedCard, ISwordTag
{
    public Card2()
    {
        CardNum = 2;

        CheckInput = FunctionCheck;
        HandleMsg = FunctionHandle;

        MaterialPath = "Picture/Card/Card2";
        WholePicturePath = "Picture/CardPicture/c2";


        weaponBuff = new Buff(buffer, false, WeaponBuffGetFunc, WeaponBuffEndFunc);

        throwSwordAction = new ActionDel("ActionBlock/Material/ThrowWeapon", ActionCheckFunc, ActionHandleFunc);

    }

    public new void FunctionCheck()
    {
        GameController gc = GameController.GetInstance();

        if (gc.controlnum == 1)//装备时
        {
            gc.SendBattleMsg();//检查无误后发送
        }
        else//暂时没有，但是也得清
        {
            gc.ClearInput();
        }
    }

    public new void FunctionHandle(MsgInBattle msg)
    {
        GameController gc = GameController.GetInstance();

        if (msg.controlNum == 1)//装装备
        {
            Block b = gc.BattleField.FindOccupantBlock(msg.targetHorizontal, msg.targetVertical);
            if (b != null) buffer = b.Owner;
            if (buffer != null)//正确状况下执行
            {
                buffer.SetElement(this, msg);
                buffer.AddBuff(weaponBuff);
                buffer.AddAction(throwSwordAction);
                buffer.SetInfo();
            }
        }
    }

    public Buff weaponBuff;

    public TriggerAble buffer;

    public void WeaponBuffGetFunc()
    {
        buffer.AttackPoint += 3;
    }

    public void WeaponBuffEndFunc()
    {
        if (buffer.AttackPoint <= 3) buffer.AttackPoint = 0;
        else { buffer.AttackPoint -= 3; }
    }

    public void Disarm()//被动缴械时调用
    {
        buffer.RemoveAction(throwSwordAction);
        buffer.RemoveBuff(weaponBuff);
    }

    public void Poison()//被动涂毒时调用
    {

    }

    public ActionDel throwSwordAction;

    public void ActionCheckFunc()
    {
        GameController gc = GameController.GetInstance();

        if (gc.target.thisType == Block.TargetType.Occupant)
        {

            if (buffer.ActionPoint > 0)
            {
                if (!gc.target.GetIsEmpty())
                {
                    gc.SendBattleMsg();//发送消息
                    Debug.Log("c2没问题");
                }
                else
                {
                    FaultMsg.ThrowFaultMsg("请选择目标");
                }
            }
            else
            {
                FaultMsg.ThrowFaultMsg("行动力不足");
            }
        }
        else
        {
            FaultMsg.ThrowFaultMsg("请选择正确的施法目标");
        }

    }
    public void ActionHandleFunc(MsgInBattle msg)
    {
        GameController gc = GameController.GetInstance();

        if (msg.targetHorizontal >= 0)
        {
            Block b = gc.BattleField.FindOccupantBlock(msg.targetHorizontal, msg.targetVertical);
            TriggerAble t = b.Owner;
            if (t != null)
            {
                buffer.ActionPoint--;
                t.GetDamage(3, 0);
                buffer.RemoveBuff(weaponBuff);
                buffer.RemoveAction(throwSwordAction);
                buffer.Disarm();
                buffer.SetInfo();
            }
        }

    }
}