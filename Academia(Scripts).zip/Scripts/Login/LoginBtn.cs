﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class LoginBtn : MonoBehaviour
{
    void Start()
    {
        ErrorText.text = "";

        Button b = GetComponent<Button>();
        b.onClick.AddListener(onClick);
    }

    void Update()
    {
        if (accountController.LoginState == "loginsuccess")
        {
            accountController.LoginState = null;
            ErrorText.text = "LoginSuccess";
            //登录成功
            //SceneManager.LoadScene("PreScene");
        }
        else if (accountController.LoginState !=null)
        {
            ErrorText.text = accountController.LoginState;
            accountController.LoginState = null;

        }
    }


    private AccountController accountController = AccountController.GetInstance();


    public Text ErrorText;
    public InputField ID;
    public InputField psw;

    void onClick()
    {
        if (accountController.CanLogin) {
            if(accountController.Login(ID.text, psw.text))
            {
                
            }
            else
            {
                ErrorText.text = "用户名或密码错误";

            }
        }
    }

    
}
