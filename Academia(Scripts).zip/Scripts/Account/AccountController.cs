﻿using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using UnityEngine;

public class AccountController 
{
    private static AccountController accountController = new AccountController();

    public static AccountController GetInstance()
    {
        return accountController;
    }



    private GlobalController gc;
    public void setGC(GlobalController globalController)
    {
        gc = globalController;
    }



    //------------------------------------账号相关-----------------------------------------


    public PlayerAccount playerAccount;

    public void SaveAccount()
    {

        BinaryFormatter bf = new BinaryFormatter();
        FileStream file = File.Create(Application.persistentDataPath + "/gamesave.save");
        bf.Serialize(file, playerAccount);
        file.Close();

        Debug.Log("Account Saved");
    }

    public bool LoadAccount()
    {
         if (File.Exists(Application.persistentDataPath + "/gamesave.save"))
         {

            BinaryFormatter bf = new BinaryFormatter();
            FileStream file = File.Open(Application.persistentDataPath + "/gamesave.save", FileMode.Open);
            PlayerAccount save = (PlayerAccount)bf.Deserialize(file);
            file.Close();

            return true;

         }
         else
         {
            return false;
        }
    }

    public void SetAccount(string id ,string psw,string nick)
    {
        playerAccount.playerID = id;
        playerAccount.password = psw;
        playerAccount.nickname = nick;
    }

    //------------------------------------登录-----------------------------------------

    public bool CanLogin = true;//false锁btn输入

    public bool Login(string id, string psw)
    {

        CanLogin = false;
        id.Replace(" ", "");//去除空格

        if (CheckStr(id)&&CheckStr(psw))
        {
            MsgLogin msg = new MsgLogin();
            msg.mission = "login";
            msg.id = id;
            msg.password = psw;
            string msgstr = JsonUtility.ToJson(msg);
            SocketHelper sh = SocketHelper.GetInstance();
            sh.SendMessage(msgstr);//发消息f
            
            return true;
        }
        else
        {
            CanLogin = true;
            LoginState = "用户名或密码格式错误";
            return false;
        }
        
    }

    public bool CheckStr(string id)
    {
        if (System.Text.RegularExpressions.Regex.IsMatch(id, @"(?i)^[0-9a-z]+$"))//只为数字字母
            return true;
        else return false;
    }

    public string LoginState;

    //-------------------------------------注册--------------------------------------------------
    public bool CanSignup = true;//false锁btn输入
    /*
    public string SignupState;

    public string SignupError;

    public bool Signup(string id, string psw,string psw2)
    {

        CanSignup = false;
        id.Replace(" ", "");//去除空格


        if (psw == psw2) { 

            if (CheckStr(id) && CheckStr(psw))
            {
                MsgLogin msg = new MsgLogin();//需要修改，真难写
                msg.mission = "signup";
                msg.id = id;
                msg.password = psw;
                string msgstr = JsonUtility.ToJson(msg);
                SocketHelper sh = SocketHelper.GetInstance();
                sh.SendMessage(msgstr);//发消息f

                return true;
            }
            else
            {
                CanSignup = true;
                SignupState = "用户名或密码格式错误";
                return false;
            }
        }
        else
        {
            CanSignup = true;
            SignupState = "两次输入密码不同";
            return false;

        }
    }*/



}
