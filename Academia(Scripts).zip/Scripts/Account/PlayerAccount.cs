﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[System.Serializable]
public class PlayerAccount 
{
    public string playerID;
    public string password;
    public string nickname;

}
