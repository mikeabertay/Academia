﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DeckManager //从外部获取卡组，并在该类中处理逻辑，目前不细写，用默认卡组解决
{
    private static DeckManager deckManager = new DeckManager();


    public static DeckManager GetInstance()
    {
        return deckManager;
    }

    public PreDeck[] Decks;//外部获取放入，目前没写就只用获取卡组函数

    public PreDeck GetDeck(int id)
    {
        return PreDeck.GetDefaultDeck(id);
    }
}
