﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PreDeck 
{
    public int hero;
    public int[] cards;
    public bool IsActive=false;
    public string name;


    public int GetHero()//获取当前英雄
    {
        return hero;
    }

    public bool CanUse()//获取当前卡组是否可用
    {
        return IsActive;
    }

    public static PreDeck GetDefaultDeck(int deckID=1)
    {
        PreDeck defaultdeck = new PreDeck(deckID);
        return defaultdeck;
    }

    PreDeck(int ID) {
        if (ID == 1)
        {
            hero = 1;
            cards =new int[30];//没写卡组里具体是啥
            IsActive = true;
            name = "艾瑞克";
        }
        else if (ID == 2)
        {
            hero = 2;
            cards = new int[30];//没写卡组里具体是啥
            IsActive = true;

        }
        else if (ID == 3)
        {
            hero = 3;
            cards = new int[30];//没写卡组里具体是啥
            IsActive = true;

        }
        else if (ID == 4)
        {
            hero = 4;
            cards = new int[30];//没写卡组里具体是啥
            IsActive = true;

        }
        else if (ID == 5)
        {
            hero = 5;
            cards = new int[30];//没写卡组里具体是啥
            IsActive = true;

        }
        else if (ID == 6)
        {
            hero = 6;
            cards = new int[30];//没写卡组里具体是啥
            IsActive = false;

        }
        else
        {
            hero = 0;
            cards = new int[30];//没写卡组里具体是啥
            IsActive = false;

        }
    }
    public PreDeck()
    {

    }

    public PreDeck(PreDeck deck)
    {
        cards = deck.cards;
        hero = deck.hero;
        IsActive = deck.IsActive;
        name = deck.name;
    }

    public void SetDeck(PreDeck deck)//废弃
    {
        cards = deck.cards;
        hero = deck.hero;
        IsActive = deck.IsActive;
        name = deck.name;
    }

    public bool CheckDeck()//内部检查卡组，具体实现以后再说
    {
        return true;
    }


}
