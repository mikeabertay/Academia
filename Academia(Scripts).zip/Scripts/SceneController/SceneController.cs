﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class SceneController 
{

    private static SceneController sceneController = new SceneController();

    public static SceneController GetInstance()
    {
        return sceneController;
    }


    int SceneTotal = 1;//场景总数
    Material[] materials;

    public void Start()//需要找人调用
    {
        materials = new Material[SceneTotal+1];

    }

    public void SetMatertials(Material[] ms)
    {
        for(int i= 0; i <= SceneTotal; i++)
        {
            materials[i] = ms[i];
        }
        
    }

    public void SelectBattleField(int scene)
    {
        SceneManager.LoadScene("Arena");

    }

    public Material GetSceneTexture(int scene)
    {
        return materials[scene];

    }
}
